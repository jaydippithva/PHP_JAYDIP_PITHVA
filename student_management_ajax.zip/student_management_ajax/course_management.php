<?php
require("db_connection.php");
require("link.php");
?>
<!DOCTYPE html>
<html>

<head>
    <title>Student AJAX CRUD</title>
</head>

<body class="container mt-4">
    <h2>Course Management (AJAX)</h2>
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#courseModal">
        Add Course
    </button>
    <button class="btn btn-success mb-3" onclick="window.location.href='index.php'">
        Back to Course Management
    </button>
    <div id="courseTable"></div>

    <!-- ================= INSERT MODAL ================= -->
    <div class="modal fade" id="courseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="courseaddForm">
                        <input type="text" name="coursename" class="form-control mb-2" placeholder="Full Name">
                        <button type="submit" class="btn btn-success w-100">Save</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- ================= EDIT MODAL ================= -->
    <div class="modal fade" id="courseeditModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Edit Course</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <form id="courseeditForm">

                        <input type="hidden" name="id" id="courseedit_id">

                        <input type="text" name="name" id="courseedit_name" class="form-control mb-2">
                        <button type="submit" class="btn btn-success w-100">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
<!-- <script>
    $(document).ready(function () {

    loadData();

    // ================= LOAD DATA =================
    function loadData() {
        $.post("course_ajax.php", { action: "fetch" }, function (data) {
            $("#courseTable").html(data);
        });
    }

    // ================= ADD COURSE =================
    $("#courseaddForm").submit(function (e) {

        e.preventDefault();
        $(".error-msg").remove();

        var name = $("input[name='coursename']");
        var valid = true;

        if (name.val().trim() == "") {
            name.after("<div class='error-msg' style='color:red;'>Name is required</div>");
            valid = false;
        } 
        else if (!/^[A-Za-z ]+$/.test(name.val().trim())) {
            name.after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
            valid = false;
        }

        if (!valid) return;

        $.ajax({
            url: "course_ajax.php",
            type: "POST",
            data: $(this).serialize() + "&action=insert",
            success: function () {

                $("#courseaddForm")[0].reset();

                var modal = bootstrap.Modal.getInstance(document.getElementById('courseModal'));
                modal.hide();

                loadData();
            }
        });
    });

    // ================= OPEN EDIT MODAL =================
    $(document).on("click", ".courseeditBtn", function () {

        var id = $(this).data("id");

        $.ajax({
            url: "course_ajax.php",
            type: "POST",
            data: { id: id, action: "getData" },
            success: function (res) {
                try {
                    var data = JSON.parse(res);

                    $("#courseedit_id").val(data.id);
                    $("#courseedit_name").val(data.course_name);

                    var modal = new bootstrap.Modal(document.getElementById('courseeditModal'));
                    modal.show();

                } catch (error) {
                    console.log(error);
                }
            }
        });
    });

    // ================= UPDATE COURSE =================
    $("#courseeditForm").submit(function (e) {

        e.preventDefault();
        $(".error-msg").remove();

        var name = $("#courseedit_name");
        var valid = true;

        if (name.val().trim() == "") {
            name.after("<div class='error-msg' style='color:red;'>Name is required</div>");
            valid = false;
        } 
        else if (!/^[A-Za-z ]+$/.test(name.val().trim())) {
            name.after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
            valid = false;
        }

        if (!valid) return;

        $.ajax({
            url: "course_ajax.php",
            type: "POST",
            data: $(this).serialize() + "&action=update",
            success: function () {

                var modalEl = document.getElementById('courseeditModal');
                var modal = bootstrap.Modal.getInstance(modalEl);
                modal.hide();

                $("#courseeditForm")[0].reset();

                loadData();
            }
        });
    });

    // ================= DELETE COURSE =================
    $(document).on("click", ".coursedeleteBtn", function () {

        if (confirm("Delete this course?")) {

            $.post("course_ajax.php", {
                id: $(this).data("id"),
                action: "delete"
            }, function () {
                loadData();
            });
        }
    });

});
</script> -->


<script>
$(document).ready(function () {

    loadData();

    // ================= LOAD DATA =================
    function loadData() {
        $.post("course_ajax.php", { action: "fetch" }, function (data) {
            $("#courseTable").html(data);
        });
    }

    // ================= LIVE VALIDATION (ADD) =================
    $("input[name='coursename']").on("keyup blur", function () {

        var value = $(this).val().trim();
        $(this).next(".error-msg").remove();

        if (value == "") {
            $(this).after("<div class='error-msg' style='color:red;'>Name is required</div>");
        }
        else if (!/^[A-Za-z ]+$/.test(value)) {
            $(this).after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
        }
    });

    // ================= ADD COURSE =================
    $("#courseaddForm button[type='submit']").click(function (e) {

        e.preventDefault();
        $(".error-msg").remove();

        var name = $("input[name='coursename']");
        var value = name.val().trim();
        var valid = true;

        if (value == "") {
            name.after("<div class='error-msg' style='color:red;'>Name is required</div>");
            valid = false;
        }
        else if (!/^[A-Za-z ]+$/.test(value)) {
            name.after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
            valid = false;
        }

        if (!valid) return;

        $.ajax({
            url: "course_ajax.php",
            type: "POST",
            data: $("#courseaddForm").serialize() + "&action=insert",
            success: function () {

                $("#courseaddForm")[0].reset();

                var modal = bootstrap.Modal.getInstance(document.getElementById('courseModal'));
                modal.hide();

                loadData();
            }
        });
    });

    // ================= OPEN EDIT MODAL =================
    $(document).on("click", ".courseeditBtn", function () {

        var id = $(this).data("id");

        $.post("course_ajax.php", {
            id: id,
            action: "getData"
        }, function (res) {

            var data = JSON.parse(res);

            $("#courseedit_id").val(data.id);
            $("#courseedit_name").val(data.course_name);

            new bootstrap.Modal(document.getElementById('courseeditModal')).show();
        });
    });

    // ================= LIVE VALIDATION (EDIT) =================
    $("#courseedit_name").on("keyup blur", function () {

        var value = $(this).val().trim();
        $(this).next(".error-msg").remove();

        if (value == "") {
            $(this).after("<div class='error-msg' style='color:red;'>Name is required</div>");
        }
        else if (!/^[A-Za-z ]+$/.test(value)) {
            $(this).after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
        }
    });

    // ================= UPDATE COURSE (NO SUBMIT) =================
    $("#courseeditForm button[type='submit']").click(function (e) {

        e.preventDefault();
        $(".error-msg").remove();

        var name = $("#courseedit_name");
        var value = name.val().trim();
        var valid = true;

        if (value == "") {
            name.after("<div class='error-msg' style='color:red;'>Name is required</div>");
            valid = false;
        }
        else if (!/^[A-Za-z ]+$/.test(value)) {
            name.after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
            valid = false;
        }

        if (!valid) return;

        $.ajax({
            url: "course_ajax.php",
            type: "POST",
            data: $("#courseeditForm").serialize() + "&action=update",
            success: function () {

                var modal = bootstrap.Modal.getInstance(document.getElementById('courseeditModal'));
                modal.hide();

                $("#courseeditForm")[0].reset();
                loadData();
            }
        });
    });

    // ================= DELETE =================
    $(document).on("click", ".coursedeleteBtn", function () {

        if (confirm("Delete this course?")) {

            $.post("course_ajax.php", {
                id: $(this).data("id"),
                action: "delete"
            }, function () {
                loadData();
            });
        }
    });

});
</script>