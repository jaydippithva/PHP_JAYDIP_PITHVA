<?php
require("db_connection.php");

/* ================= FETCH ================= */
if ($_POST['action'] === "fetch") {

    $query = "SELECT * FROM course";

    $result = mysqli_query($con, $query);

    echo "<table class='table table-bordered'>
            <tr>
                <th>Name</th>
                <th>Action</th>
            </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['course_name']}</td>
                <td>
                    <button class='btn btn-warning btn-sm courseeditBtn' data-id='{$row['id']}'>Edit</button>
                    <button class='btn btn-danger btn-sm coursedeleteBtn' data-id='{$row['id']}'>Delete</button>
                </td>
              </tr>";
    }

    echo "</table>";
}

/* ================= INSERT ================= */
if ($_POST['action'] == "update") {

    $id = $_POST['id'];

    mysqli_query($con, "UPDATE course SET course_name='{$_POST['name']}' WHERE id='$id'");
}


if ($_POST['action'] == "getData") {

    $id = $_POST['id'];

    $result = mysqli_query($con, "SELECT * FROM course WHERE id='$id'");
    $row = mysqli_fetch_assoc($result);

    echo json_encode($row);
    exit;
}


if ($_POST['action'] == "insert") {
    mysqli_query($con, "INSERT INTO course SET
                        course_name='{$_POST['coursename']}'");
}

/* ================= DELETE ================= */
if ($_POST['action'] == "delete") {
    mysqli_query($con, "DELETE FROM course WHERE id='{$_POST['id']}'");
}
