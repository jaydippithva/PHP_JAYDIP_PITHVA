<?php
require("db_connection.php");
require("link.php");
?>
<!DOCTYPE html>
<html>

<head>
    <title>Student AJAX CRUD</title>

</head>

<body class="container mt-4">

    <h2>Student Management (AJAX)</h2>

    <input type="text" id="search" class="form-control mb-3" placeholder="Search student by name...">

    <select id="limit" class="form-select mb-3" style="width:150px;">
        <option value="5">5 Records</option>
        <option value="10">10 Records</option>
        <option value="all">All Records</option>
    </select>

    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#studentModal">
        Add Student
    </button>
    <button class="btn btn-success mb-3" onclick="window.location.href='course_management.php'">
        Course Management
    </button>

    <div id="studentTable"></div>
    <!-- ================= INSERT MODAL ================= -->

    <div class="modal fade" id="studentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Add Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <form id="addForm">

                        <input type="text" name="name" class="form-control mb-2" placeholder="Full Name">
                        <input type="email" name="email" class="form-control mb-2" placeholder="Email">
                        <input type="text" name="phoneno" class="form-control mb-2" placeholder="Phone Number">

                        <div class="mb-2">
                            Gender:
                            <input type="radio" name="gender" value="Male"> Male
                            <input type="radio" name="gender" value="Female"> Female
                        </div>

                        <input type="date" name="dob" class="form-control mb-2">

                        <select name="course_id" class="form-control mb-2">
                            <option value="">-- Select Course --</option>
                            <?php
                            $course = mysqli_query($con, "SELECT * FROM course");
                            while ($c = mysqli_fetch_assoc($course)) {
                                echo "<option value='{$c['id']}'>{$c['course_name']}</option>";
                            }
                            ?>
                        </select>

                        <button type="submit" class="btn btn-success w-100">Save</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <!-- ================= EDIT MODAL ================= -->
    <div class="modal fade" id="editModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Edit Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <form id="editForm">

                        <input type="hidden" name="id" id="edit_id">

                        <input type="text" name="name" id="edit_name" class="form-control mb-2" required>
                        <input type="email" name="email" id="edit_email" class="form-control mb-2" required>
                        <input type="text" name="phoneno" id="edit_phone" class="form-control mb-2" required>

                        <div class="mb-2">
                            Gender:
                            <input type="radio" name="gender" value="Male"> Male
                            <input type="radio" name="gender" value="Female"> Female
                        </div>

                        <input type="date" name="dob" id="edit_dob" class="form-control mb-2" required>

                        <select name="course_id" id="edit_course" class="form-control mb-2" required>
                            <option value="">-- Select Course --</option>
                            <?php
                            $course = mysqli_query($con, "SELECT * FROM course");
                            while ($c = mysqli_fetch_assoc($course)) {
                                echo "<option value='{$c['id']}'>{$c['course_name']}</option>";
                            }
                            ?>
                        </select>

                        <button type="submit" class="btn btn-success w-100">Update</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <script>
        $(document).ready(function() {

            loadData();

            function loadData(page = 1) {
                $.post("student_ajax.php", {
                    action: "fetch",
                    page: page,
                    search: $("#search").val(),
                    limit: $("#limit").val()
                }, function(data) {
                    $("#studentTable").html(data);
                });
            }

            $("#search").keyup(function() {
                loadData();
            });
            $("#limit").change(function() {
                loadData();
            });

            $(document).on("click", ".page-link", function(e) {
                e.preventDefault();
                loadData($(this).data("page"));
            });

            // ADD
            $("#addForm").submit(function(e) {

                e.preventDefault();

                $(".error-msg").remove(); // remove old errors

                var name = $("input[name='name']");
                var email = $("input[name='email']");
                var phone = $("input[name='phoneno']");
                var gender = $("input[name='gender']:checked");
                var dob = $("input[name='dob']");
                var course = $("select[name='course_id']");

                var valid = true;

                // NAME
                if (name.val().trim() == "") {
                    name.after("<div class='error-msg' style='color:red;'>Name is required</div>");
                    valid = false;
                } else if (!/^[A-Za-z ]+$/.test(name.val())) {
                    name.after("<div class='error-msg' style='color:red;'>Only letters allowed</div>");
                    valid = false;
                }

                // EMAIL
                if (email.val().trim() == "") {
                    email.after("<div class='error-msg' style='color:red;'>Email is required</div>");
                    valid = false;
                }

                // PHONE
                if (!/^[1-9]{10}$/.test(phone.val())) {
                    phone.after("<div class='error-msg' style='color:red;'>Phone must be 10 digits</div>");
                    valid = false;
                }

                // GENDER
                if (gender.length == 0) {
                    $("input[name='gender']").last().after("<div class='error-msg' style='color:red;'>Select gender</div>");
                    valid = false;
                }

                // DOB
                if (dob.val() == "") {
                    dob.after("<div class='error-msg' style='color:red;'>Date of birth required</div>");
                    valid = false;
                }

                // COURSE
                if (course.val() == "") {
                    course.after("<div class='error-msg' style='color:red;'>Select course</div>");
                    valid = false;
                }

                if (!valid) return;

                // AJAX INSERT
                $.ajax({
                    url: "student_ajax.php",
                    type: "POST",
                    data: $(this).serialize() + "&action=insert",
                    success: function() {

                        $("#addForm")[0].reset();

                        var modal = bootstrap.Modal.getInstance(document.getElementById('studentModal'));
                        modal.hide();

                        loadData();
                    }
                });

            });

            // OPEN EDIT MODAL
            $(document).on("click", ".editBtn", function() {

                var id = $(this).data("id");

                $.ajax({
                    url: "student_ajax.php",
                    type: "POST",
                    data: {
                        id: id,
                        action: "getData"
                    },

                    success: function(res) {

                        console.log(res);
                        try {
                            var modal = new bootstrap.Modal(document.getElementById('editModal'));
                            modal.show();
                            var data = JSON.parse(res);
                            $("#edit_id").val(data.id);
                            $("#edit_name").val(data.name);
                            $("#edit_email").val(data.email);
                            $("#edit_phone").val(data.phoneno);
                            $("#edit_dob").val(data.birthdate);
                            $("#edit_course").val(data.course_id);


                            $("#editForm input[name='gender'][value='" + data.gender + "']")
                                .prop("checked", true)

                        } catch (error) {
                            console.log(error);
                        }
                    },
                    error: function(res) {
                        console.log(res);
                    }

                });

                // UPDATE
                $("#editForm").submit(function(e) {
                    e.preventDefault();

                    $.ajax({
                        url: "student_ajax.php",
                        type: "POST",
                        data: $(this).serialize() + "&action=update",
                        success: function() {

                            var modalEl = document.getElementById('editModal');
                            var modal = bootstrap.Modal.getInstance(modalEl);
                            modal.hide();

                            $("#editForm")[0].reset();
                            loadData();
                        }
                    });
                });

            });

            // DELETE
            $(document).on("click", ".deleteBtn", function() {
                if (confirm("Delete this student?")) {
                    $.post("student_ajax.php", {
                        id: $(this).data("id"),
                        action: "delete"
                    }, function() {
                        loadData();
                    });
                }
            });

        });
    </script>
</body>

</html>
<script>
    // Remove old error message
    function showError(input, message) {
        input.next(".error-msg").remove();
        input.removeClass("valid-input").addClass("invalid-input");
        input.after("<div class='error-msg ' style='color:red;'>" + message + "</div>");
    }

    function showSuccess(input) {
        input.next(".error-msg").remove();
        input.removeClass("invalid-input").addClass("valid-input");
    }


    // ================= NAME =================
    $("input[name='name'], #edit_name").on("keyup blur", function() {

        var value = $(this).val().trim();

        if (value == "") {
            showError($(this), "Name is required");
        } else if (!/^[A-Za-z ]+$/.test(value)) {
            showError($(this), "Only letters allowed");
        } else {
            showSuccess($(this));
        }

    });


    // ================= EMAIL =================
    $("input[name='email'], #edit_email").on("keyup blur", function() {

        var value = $(this).val().trim();

        if (value == "") {
            showError($(this), "Email is required");
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
            showError($(this), "Invalid email format");
        } else {
            showSuccess($(this));
        }

    });


    // ================= PHONE =================
    $("input[name='phoneno'], #edit_phone").on("keyup blur", function() {

        var value = $(this).val().trim();

        if (!/^[0-9]{10}$/.test(value)) {
            showError($(this), "Phone must be 10 digits");
        } else {
            showSuccess($(this));
        }

    });


    // ================= DOB =================
    $("input[name='dob'], #edit_dob").on("change keyup blur", function() {

        if ($(this).val() == "") {
            showError($(this), "Date of birth required");
        } else {
            showSuccess($(this));
        }

    });


    // ================= COURSE =================
    $("select[name='course_id'], #edit_course").on("change keyup blur", function() {

        if ($(this).val() == "") {
            showError($(this), "Select a course");
        } else {
            showSuccess($(this));
        }

    });
</script>