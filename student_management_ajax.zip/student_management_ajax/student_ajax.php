<?php
require("db_connection.php");

/* ================= FETCH ================= */
if ($_POST['action'] === "fetch") {

    $page = isset($_POST['page']) ? $_POST['page'] : 1;
    $limit = $_POST['limit'];
    $search = $_POST['search'];

    $searchQuery = "";
    if (!empty($search)) {
        $searchQuery = "WHERE s.name LIKE '%$search%'";
    }

    // Count total records
    $countQuery = "SELECT COUNT(*) as total FROM std s $searchQuery";
    $countResult = mysqli_query($con, $countQuery);
    $totalRow = mysqli_fetch_assoc($countResult);
    $totalRecords = $totalRow['total'];

    if ($limit != "all") {
        $limit = (int)$limit;
        $start = ($page - 1) * $limit;
        $totalPages = ceil($totalRecords / $limit);
        $limitQuery = "LIMIT $start,$limit";
    } else {
        $limitQuery = "";
        $totalPages = 1;
    }

    $query = "SELECT s.*,c.course_name
            FROM std s
            LEFT JOIN course c ON s.course_id=c.id
            $searchQuery
            ORDER BY s.id DESC
            $limitQuery";

    $result = mysqli_query($con, $query);

    echo "<table class='table table-bordered'>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Course</th>
                <th>Action</th>
            </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['phoneno']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['birthdate']}</td>
                <td>{$row['course_name']}</td>
                <td>
                    <button class='btn btn-warning btn-sm editBtn' data-id='{$row['id']}'>Edit</button>
                    <button class='btn btn-danger btn-sm deleteBtn' data-id='{$row['id']}'>Delete</button>
                </td>
              </tr>";
    }

    echo "</table>";

    // Pagination
    if ($limit != "all" && $totalPages > 1) {
        echo "<nav><ul class='pagination'>";
        for ($i = 1; $i <= $totalPages; $i++) {
            $active = ($i == $page) ? "active" : "";
            echo "<li class='page-item $active'>
                    <a href='#' class='page-link' data-page='$i'>$i</a>
                  </li>";
        }
        echo "</ul></nav>";
    }
}

/* ================= INSERT ================= */
if ($_POST['action'] == "update") {

    $id = $_POST['id'];

    mysqli_query($con, "UPDATE std SET 
        name='{$_POST['name']}',
        email='{$_POST['email']}',
        phoneno='{$_POST['phoneno']}',
        gender='{$_POST['gender']}',
        birthdate='{$_POST['dob']}',
        course_id='{$_POST['course_id']}'
        WHERE id='$id'
    ");
}


if ($_POST['action'] == "getData") {

    $id = $_POST['id'];

    $result = mysqli_query($con, "SELECT * FROM std WHERE id='$id'");
    $row = mysqli_fetch_assoc($result);

    echo json_encode($row, JSON_PRETTY_PRINT);
exit;
}


if ($_POST['action'] == "insert") {
    mysqli_query($con, "INSERT INTO std SET
                        name='{$_POST['name']}',
                        email='{$_POST['email']}',
                        phoneno='{$_POST['phoneno']}',
                        gender='{$_POST['gender']}',
                        birthdate='{$_POST['dob']}',
                        course_id='{$_POST['course_id']}'");
}

/* ================= DELETE ================= */
if ($_POST['action'] == "delete") {
    mysqli_query($con, "DELETE FROM std WHERE id='{$_POST['id']}'");
}
