<?php
    $con=mysqli_connect("localhost", "root", "", "std_ajax");
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>
