<?php

echo '<pre>';
$size = 9;   // r and c
$mid  = ceil($size / 2);

for ($i = 1; $i <= $size; $i++) {

    if ($i <= $mid) {
        $k = $i; // upper
    } else {
        $k = $size - $i + 1; // lower 
    }

    for ($j = 1; $j <= $size; $j++) { // for colume

        if ($j <= $k || $j >= ($size - $k + 1)) {
            echo "* ";
        } else {
            echo "&nbsp;&nbsp;";
        }
    }

    echo "<br>";
}

echo '</pre>';
echo '<pre>';

$num = 5;
for ($i = 0; $i < $num; $i++) {
    for ($j = 0; $j <= $i; $j++) {
        echo "# ";
    }
    echo "<br>";
}

// echo "<br>";

$num = 1;
for ($i = 5; $i >= $num; $i--) {
    for ($j = 1; $j <= $i; $j++) {
        echo "# ";
    }
    echo "<br>";
}

echo "<br>";

$str = "hiren";
$count = strlen($str);

for ($i = 0; $i < $count; $i++) {
    for ($j = 0; $j <= $i; $j++) {
        echo "$str[$j]";
    }
    echo "<br>";
}
for ($i = $count - 1; $i >= 0; $i--) {
    for ($j = 0; $j < $i; $j++) {
        echo "$str[$j]";
    }
    echo "<br>";
}

$num = 5;
for ($i = 1; $i <= $num; $i++) {
    for ($j = 1; $j <= $num; $j++) {
        if ($j <= ($num - $i)) { // for space from left to right
            // echo "&nbsp" . "&nbsp";
            echo " " . " ";
        } else {
            echo "# ";
        }
    }
    echo "<br>";
}

$num = 8;
for ($i = 1; $i <= $num; $i++) {
    for ($j = 1; $j <= $num; $j++) {
        if ($j <= ($num - $i)) {
            echo " ";
        } else {
            echo "# ";
        }
    }
    echo "<br>";
}
for ($i = $num - 1; $i >= 1; $i--) {
    for ($j = 1; $j <= $num; $j++) {
        if ($j <= ($num - $i)) {
            echo " ";
        } else {
            echo "# ";
        }
    }
    echo "<br>";
}

$n = 1;
for ($i = 0; $i < $num; $i++) {
    for ($j = 0; $j <= $i; $j++) {
        echo $n++ . "&nbsp";
    }
    echo "<br>";
}

$n = 1;
for ($i = 0; $i < $num; $i++) {
    for ($j = 0; $j < $i; $j++) {
        echo $n . "&nbsp";
    }
    echo $n++;
    echo "<br>";
}

$n = 65;
for ($i = 0; $i < $num; $i++) {
    for ($j = 0; $j <= $i; $j++) {
        $ch = chr($n);
        echo $ch . "&nbsp";
    }
    $n++;
    echo "<br>";
}

$n = 65;
for ($i = 0; $i < $num; $i++) {
    for ($j = 0; $j <= $i; $j++) {
        $ch = chr($n);
        echo $ch . "&nbsp";
        $n++;
    }
    echo "<br>";
}

echo "<br>";

$num = 10;
$n = 65;
for ($i = 0; $i < $num; $i++) {
    $ch = $n + $i;
    echo chr($ch) . " ";
    $next = $ch + 9;
    for ($j = 1; $j <= $i; $j++) {
        $ch = chr($next);
        echo $ch . "&nbsp";
        $next += 8;
    }
    echo "<br>";
}

// $n = 64;
$n = 8;
for ($i = 0; $i < $n; $i++) {
    for ($j = 0; $j <= $n; $j++) {
        if ($j == $i or $j + $i == $n - 1)
            echo "*";
        else
            echo " ";
    }
    echo "<br>";
}

echo '</pre>';
