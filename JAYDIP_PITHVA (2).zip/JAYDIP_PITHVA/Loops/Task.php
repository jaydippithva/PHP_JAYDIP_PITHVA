<?php

echo '<pre>';
$n = 5;

for ($i = 1; $i <= $n; $i++) { // this loop for upper hafe
    for ($j = $n - $i + 1; $j >= 1; $j--) { //left
        if ($i % 2 == 0) {
            echo "<span style='color:red;'>$i</span>";
            continue;
        }
        echo $i;
    }
    for ($k = 1; $k <= ($i - 1) * 2; $k++) { // space k = 2
        echo "&nbsp;";
    }
    for ($j = $n - $i + 1; $j >= 1; $j--) { //right
        if ($i % 2 == 0) {
            echo "<span style='color:red;'>$i</span>";
            continue;
        }
        echo $i;
    }
    echo "<br>";
}
for ($i = 1; $i <= $n - 1; $i++) { // lower hafe
    for ($j = 1; $j <= $i + 1; $j++) { // left side
        if ($i % 2 == 0) {
            echo "<span style='color:red;'>$i</span>";
            continue;
        }
        echo $i;
    }
    for ($k = ($n - $i) * 2 - 2; $k >= 1; $k--) { // space k = 6
        echo "&nbsp;";
    }
    for ($j = 1; $j <= $i + 1; $j++) { // right side
        if ($i % 2 == 0) {
            echo "<span style='color:red;'>$i</span>";
            continue;
        }
        echo $i;
    }
    echo "<br>";
}

echo "<br>pascal<br>";

$rows = 10; // r
for ($i = 0; $i < $rows; $i++) {
    for ($space = 0; $space < $rows - $i; $space++) {
        echo "&nbsp;";
    }
    $num = 1; // all row star with 1
    for ($j = 0; $j <= $i; $j++) {
        echo $num . " ";
        $num = $num * ($i - $j) / ($j + 1); // formula to calculate
    }
    echo "<br>";
}

echo "<br> next <br>";

$size = 9;   // r and c
$mid  = ceil($size / 2); // ceil make 4.5 to 5

for ($i = 1; $i <= $size; $i++) {

    if ($i <= $mid) {
        $k = $i; // upper
    } else {
        $k = $size - $i + 1; // lower 
    }

    for ($j = 1; $j <= $size; $j++) { // for colume
        if ($j <= $k || $j >= ($size - $k + 1)) {
            echo "* ";
        } else {
            echo "&nbsp;&nbsp;";
        }
    }

    echo "<br>";
}

$size = 9;
$mid  = ceil($size / 2);

echo "<table border='1' cellspacing='3' cellpadding='10'>";

for ($i = 1; $i <= $size; $i++) {

    echo "<tr>";

    if ($i <= $mid) {
        $k = $i;
    } else {
        $k = $size - $i + 1;
    }

    for ($j = 1; $j <= $size; $j++) {

        if ($j <= $k || $j >= ($size - $k + 1)) {
            echo "<td style='background:red; text-align:center;'>*</td>";
        } else {
            echo "<td></td>";
        }
    }
    echo "</tr>";
}
echo "</table>";

echo '</pre>';
