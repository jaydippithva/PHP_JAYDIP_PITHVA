<?php
require("../javascript/student_management/db.php");
require("../javascript/student_management/header.php");
$name = $_GET['q'];
$q = mysqli_query($con, "SELECT * from std where `first_name`='$name'");

while ($res = mysqli_fetch_assoc($q)) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><?php echo $res['first_name']; ?></h1>
</body>
</html>
<?php
}
?>