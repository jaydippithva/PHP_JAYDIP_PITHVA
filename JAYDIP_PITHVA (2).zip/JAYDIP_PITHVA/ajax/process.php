<?php
require("../javascript/student_management/db.php");
require("../javascript/student_management/header.php");

$q = mysqli_query($con, "SELECT * FROM std");
?>

<div class="container mt-4">
    <table class="table table-bordered table-striped mt-3">
        <tr>
            <th>
                id
            </th>
            <th>
                firstname
            </th>
            <th>
                lastname
            </th>
            <th>
                email
            </th>
        </tr>
        <?php
        while ($row = mysqli_fetch_assoc($q)) { ?>
            <tr>
                <td>
                    <?= $row['id'] ?>
                </td>
                <td>
                    <?= $row['first_name'] ?>
                </td>
                <td>
                    <?= $row['last_name'] ?>
                </td>
                <td>
                    <?= $row['email'] ?>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
</div>