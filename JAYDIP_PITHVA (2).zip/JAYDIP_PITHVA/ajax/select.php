<script>
    function showdata(str) {
        if (str == "") {
            document.getElementById("output").innerHTML = "";
            return;
        } else {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("output").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "get.php?q=" + str, true);
            xmlhttp.send();
        }
    }
</script>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div>
        <select name="username" onchange="showdata(this.value)">
            <option value="">Select Username</option>
            <option value="jaydip">jaydip</option>
            <option value="rahul">rahul</option>
        </select>
    </div>
    <div id="output">

    </div>
</body>

</html>