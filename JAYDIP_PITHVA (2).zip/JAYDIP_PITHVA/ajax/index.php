<!DOCTYPE html>
<html>
<head>
    <title>Simple AJAX Example</title>
</head>
<body>

<h2>Enter Your Name</h2>

<input type="text" id="username" placeholder="Enter name">
<button onclick="sendData()">Submit</button>

<p id="result"></p>

<script>
function sendData() {
    let name = document.getElementById("username").value;

    let xhr = new XMLHttpRequest();
    xhr.open("POST", "process.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhr.onload = function() {
        if(this.status == 200) {
            document.getElementById("result").innerHTML = this.responseText;
        }
    }

    xhr.send("username=" + name);
}
</script>

</body>
</html>