<?php
    require("db.php");
    require("header.php");

    $q="SELECT * FROM course";
    $row=mysqli_query($con,$q)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="container mt-4">
    <h2 class="mb-4">Course Management</h2>
    <a href="addcourse.php" class="btn btn-primary"> Add Course</a>
    <a href="index.php" class="btn btn-success"> Show Student</a>

    <table class="table table-bordered table-striped mt-3">
            <tr class="table-dark">
                <th>Course Name</th>
                <th>Action</th>
            </tr>
    <?php
        while($res=mysqli_fetch_assoc($row))
        {
    ?>
    <tr>
        <td><?= $res['name']; ?></td>
        <td>
            <a href="cview.php?id=<?= $res['id'] ?>" class="btn btn-sm btn-primary">View</a>
            <a href="cedit.php?id=<?= $res['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="cdelete.php?id=<?= $res['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
        </td>
    </tr>

    <?php } ?>
</body>
</html>