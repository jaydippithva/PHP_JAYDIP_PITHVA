<?php
require("db.php");
require("header.php");

$limit = 5;

if (isset($_GET['limit'])) {
    if ($_GET['limit'] == "all") {
        $limit = 0;
    } else {
        $limit = (int)$_GET['limit'];
    }
}



$allowed_columns = ['id', 'first_name', 'last_name', 'email', 'course_id', 'gender'];
$order_column = "name";      // default column
$order_direction = "ASC";  // default order

if (isset($_GET['sort']) && in_array($_GET['sort'], $allowed_columns)) {
    $order_column = $_GET['sort'];
}

if (isset($_GET['order']) && $_GET['order'] == "DESC") {
    $order_direction = "DESC";
} else {
    $order_direction = "ASC";
}



$search = "";
$where = "";

if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $where = "WHERE std.first_name LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total 
                FROM std 
                INNER JOIN course ON std.course_id = course.id 
                $where  ORDER BY $order_column $order_direction";

$count_result = mysqli_query($con, $count_query);
$count_row = mysqli_fetch_assoc($count_result);
$total_records = $count_row['total'];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = ($page <= 0) ? 1 : $page;

if ($limit > 0) {
    $start = ($page - 1) * $limit;

    $query = "SELECT std.*, course.name AS course_name
              FROM std
              INNER JOIN course ON std.course_id = course.id
              $where  ORDER BY $order_column $order_direction
              LIMIT $start, $limit";
} else {
    $query = "SELECT std.*, course.name AS course_name
              FROM std
              INNER JOIN course ON std.course_id = course.id
              $where  ORDER BY $order_column $order_direction";
}

$result1 = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Student View</title>
</head>

<body class="container mt-4">

    <h2 class="mb-4">Student Management</h2>

    <div class="mb-3">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Insert Student
        </button>
        <a href="courseview.php" class="btn btn-info">Course View</a>
    </div>

    <form method="GET" class="row mb-3">

        <div class="col-md-4">
            <input type="text" name="search" value="<?= $search ?>"
                class="form-control" placeholder="Search by First Name">
        </div>

        <div class="col-md-3">
            <select name="limit" class="form-select">
                <option value="5" <?= ($limit == 5) ? 'selected' : '' ?>>First 5 Records</option>
                <option value="10" <?= ($limit == 10) ? 'selected' : '' ?>>First 10 Records</option>
                <option value="all" <?= ($limit == 0) ? 'selected' : '' ?>>All Records</option>
            </select>
        </div>

        <div class="col-md-2">
            <button type="submit" class="btn btn-dark">Apply</button>
        </div>

        <table class="table table-bordered table-striped mt-3">
            <?php

            $new_order = ($order_direction == "ASC") ? "DESC" : "ASC";
            ?>
            <tr class="table-dark">
                <th>
                    ID
                </th>
                <th>
                    <a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=first_name&order=<?= $new_order ?>">
                        First Name
                    </a>
                </th>
                <th>
                    <a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=last_name&order=<?= $new_order ?>">
                        Last Name
                    </a>
                </th>
                <th><a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=email&order=<?= $new_order ?>">
                        Email
                    </a>
                </th>
                <th>
                    Contact Number
                </th>
                <th>
                    Birthdate
                </th>
                <th><a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=gender&order=<?= $new_order ?>">
                        Gender
                    </a>
                </th>
                <th><a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=course_name&order=<?= $new_order ?>">
                        Course
                    </a></th>
                <th>Actions</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result1)) { ?>

                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['first_name'] ?></td>
                    <td><?= $row['last_name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['contact_number'] ?></td>
                    <td><?= $row['birthdate'] ?></td>
                    <td><?= $row['gender'] ?></td>
                    <td><?= $row['course_name'] ?></td>
                    <td>
                        <a href="view.php?id=<?= $row['id'] ?>&page=<?= $page ?>&limit=<?= $limit ?>" class="btn btn-sm btn-primary">View</a>
                        <a href="edit.php?id=<?= $row['id'] ?>&page=<?= $page ?>&limit=<?= $limit ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="delete.php?id=<?= $row['id'] ?>&page=<?= $page ?>&limit=<?= $limit ?>" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>

            <?php } ?>

        </table>
    </form>

    <?php
    if ($limit > 0) {
        $total_pages = ceil($total_records / $limit);

        echo '<nav><ul class="pagination">';

        for ($i = 1; $i <= $total_pages; $i++) {
            $active = ($i == $page) ? "active" : "";
            echo "<li class='page-item $active'>
                <a class='page-link' 
                href='?page=$i&limit=$limit&search=$search'>$i</a>
              </li>";
        }

        echo '</ul></nav>';
    }
    ?>

    <?php

    $errors = [];

    if (isset($_POST['register'])) {

        //echo "hell";exit;
        $fname = trim($_POST['fname']);
        $lname = trim($_POST['lname']);
        $email = trim($_POST['email']);
        $contactno = trim($_POST['contactno']);
        $birthdate = $_POST['birthdate'];
        $gender = $_POST['gender'] ?? '';
        $course = $_POST['course'] ?? '';

        if (empty($fname))
            $errors['fname'] = "First Name is required";
        elseif (!preg_match("/^[A-Za-z ]+$/", $fname))
            $errors['fname'] = "Only letters allowed";

        if (empty($lname))
            $errors['lname'] = "Last Name is required";



        if (empty($email))
            $errors['email'] = "Email is required";
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))
            $errors['email'] = "Invalid email format";

        $q = "SELECT `email` from `std` where `email`='$email'";
        $row = (mysqli_num_rows(mysqli_query($con, $q)));
        if ($row == 1)
            $errors['email'] = "Email Already Registered!!!";


        if (empty($contactno))
            $errors['contactno'] = "Contact number required";
        elseif (!preg_match("/^[6-9][0-9]{9}$/", $contactno))
            $errors['contactno'] = "Enter valid 10 digit number & Indian Number";

        if (empty($birthdate))
            $errors['birthdate'] = "Birthdate required";

        if (empty($gender))
            $errors['gender'] = "Select gender";

        if (empty($course))
            $errors['course'] = "Select course";

        if (empty($errors)) {
            $q = "INSERT INTO `std`(`first_name`, `last_name`, `email`, `contact_number`, `birthdate`, `gender`, `course_id`) 
                    VALUES ('$fname','$lname','$email','$contactno','$birthdate','$gender','$course')";
            $row = mysqli_query($con, $q);
            if ($row) {
                $fname = '';
                $lname = '';
                $email = '';
                $contactno = '';
                $birthdate = '';
                $gender = '';
                $course = '';
                $errors = '';
                exit;
            }
        }
    }
    ?>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add Student</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname">
                            <div class="text-danger">
                                <?= $errors['fname'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname">
                            <div class="text-danger">
                                <?= $errors['lname'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email">
                            <div class="text-danger">
                                <?= $errors['email'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" name="contactno">
                            <div class="text-danger">
                                <?= $errors['contactno'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Birthdate</label>
                            <input type="date" class="form-control" name="birthdate">
                            <div class="text-danger">
                                <?= $errors['birthdate'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gender</label>

                            <div class="form-check">
                                <input class="form-check-input" type="radio"
                                    name="gender" value="Male" id="male">
                                <label class="form-check-label" for="male">
                                    Male
                                </label>
                            </div>

                            <div class="form-check">
                                <input class="form-check-input" type="radio"
                                    name="gender" value="Female" id="female">
                                <label class="form-check-label" for="female">
                                    Female
                                </label>
                            </div>
                            <div class="text-danger">
                                <?= $errors['gender'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Course</label>

                            <select name="course" class="form-select">
                                <option value="" disabled selected>-- Select Course --</option>
                                <?php
                                $q = "SELECT * FROM course";
                                $row1 = mysqli_query($con, $q);
                                while ($res1 = mysqli_fetch_assoc($row1)) {
                                ?>
                                    <option value="<?= $res1['id']; ?>"><?= $res1['name']; ?></option>
                                <?php } ?>
                            </select>
                            <div class="text-danger">
                                <?= $errors['course'] ?? '' ?>
                            </div>
                        </div>
                        <button type="submit" name="register" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>