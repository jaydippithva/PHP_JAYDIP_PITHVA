<?php
// 1) Read csv file
$data = fopen("data.csv", "r");
$newFile = fopen("DR10.csv", "w"); // creating new file

// 2) Number column read and find record " DR10 " write to new csv

$header = fgetcsv($data);
fputcsv($newFile, $header);

while (($row = fgetcsv($data)) !== FALSE) {
    if (str_starts_with($row[1], 'DR10')) { 
        fputcsv($newFile, $row); // write the row to new file
    }
}
echo "DR10 records written to DR10.csv successfully!";

// 3) Convert date column[3] (1633427368) to Date format (dd-mm-yyyy) modify in data.csv file

$filename = 'data.csv';
$datename = 'date_converted.csv';
$input = fopen($filename, 'r');
$output = fopen($datename, 'w');

// Loop through each row
while (($row = fgetcsv($input)) !== FALSE) {
    // We check if it's numeric to avoid converting the header "Date"
    if (isset($row[3]) && is_numeric($row[3])) {
        // Convert timestamp 1633427368 to 05-10-2021
        $row[3] = date('d-m-Y', (int)$row[3]); // changeing date
    }
    fputcsv($output, $row);
}

fclose($input);
fclose($output);
echo "Date Conversion complete!";

// 4) Create new column in csv for "Password" and Encrypt Number column data to md5

$inputFile = "date_converted.csv";
$outputFile = "pass_col_added.csv";
$read = fopen($inputFile, "r");
$write = fopen($outputFile, "w");

$firstRow = true;

while (($row = fgetcsv($read)) !== false) {

    // Add column header in first row
    if ($firstRow) {
        $row[] = "Password"; // Add new column name
        $firstRow = false;
    } else {
        $row[] = '';
    }

    fputcsv($write, $row);
}

fclose($read);
fclose($write);
echo "Password column added successfully!";

$inputFile = "pass_col_added.csv";
$outputFile = "encrypted_number_col.csv";
$read = fopen($inputFile, "r");
$write = fopen($outputFile, "w");

$rowNumber = 0;

while (($row = fgetcsv($read)) !== false) {
    if ($rowNumber > 0) {
        // Encrypt column at index 1
        if (isset($row[1])) {
            $row[1] = md5($row[1]); // md5 make encryption of string with 32chrecter changing col 2 with index 1
        }
    }
    fputcsv($write, $row);
    $rowNumber++;
}

fclose($read);
fclose($write);
echo "Column encrypted successfully!";

// 5) Purchase Price column should be rounded value

$inputFile = "encrypted_number_col.csv";
$outputFile = "rounded_price.csv";
$read = fopen($inputFile, "r");
$write = fopen($outputFile, "w");

$rowNumber = 0;

while (($row = fgetcsv($read)) !== false) {
    if ($rowNumber > 0) {
        if (isset($row[11])) { // rounding index 11 col 10 
            $row[11] = round($row[11]);
        }
    }

    fputcsv($write, $row);
    $rowNumber++;
}

fclose($read);
fclose($write);
echo "Column price rounded successfully!";

// 6) Create new column "indlude tax price" and set data from column price_with_taxes + 25%

$inputFile = "rounded_price.csv";
$outputFile = "tax_price.csv";
$read = fopen($inputFile, "r");
$write = fopen($outputFile, "w");

$firstRow = true;

while (($row = fgetcsv($read)) !== false) {
    // Add column header in first row
    if ($firstRow) {
        $row[] = "indlude_tax_price"; // name of new col
        $firstRow = false;
    } else {
        $row[] = (float)$row[14] * 1.25;
    }
    fputcsv($write, $row);
}

fclose($read);
fclose($write);

echo "Tax Priced column added successfully!";

// 7) Create new column "Create date"

$inputFile = "tax_price.csv";
$outputFile = "create_date_col.csv";

$read = fopen($inputFile, "r");
$write = fopen($outputFile, "w");

$firstRow = true;

while (($row = fgetcsv($read)) !== false) {

    // Add column header in first row
    if ($firstRow) {
        $row[] = "Create_date"; // Add new column name
        $firstRow = false;
    } else {
        $row[] = date('d-m-y');
    }

    // Write updated row to new file
    fputcsv($write, $row);
}

fclose($read);
fclose($write);
echo "Create date column added successfully!";

$lastCSV = fopen("create_date_col.csv", "r");
while (! feof($lastCSV)) {
    echo "<pre>";
    print_r(fgetcsv($lastCSV));
    echo "</pre>";
}

fclose($lastCSV);
fclose($newFile);
fclose($data);
