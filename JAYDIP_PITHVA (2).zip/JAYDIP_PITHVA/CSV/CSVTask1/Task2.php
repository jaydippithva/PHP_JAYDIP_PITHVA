<?php

$str = "Solitari, Anelli, Bracciali, Ciondoli, Collane, Collane E Pendenti, Diamanti, Fedi E Fedine, Fermasoldi, Gemelli, Girocolli, Orecchini, Orologi, Portachiavi, Solitari, Spille, Charms, Componenti, OROLOGI";

$categories = array_map('trim', explode(",", $str)); // Convert string to array

$data = fopen("data.csv", "r");
$newFile = fopen("arrTOarr.csv", "w");

$header = fgetcsv($data);
fputcsv($newFile, $header);

while (($row = fgetcsv($data)) !== false) {
    $rowAssoc = array_combine($header, array_pad($row, count($header), ''));

    $tags = array_map('trim', explode(",", $rowAssoc['Tags'])); // Convert Tags column into array
    $matched = array_intersect($categories, $tags); // Find matching words between two arrays

    $rowAssoc['Category'] = !empty($matched) ? "[" . implode(", ", array_map(fn($item) => '"' . $item . '"', $matched)) . "]" : "";
    fputcsv($newFile, $rowAssoc);
}

echo "File Created...";

fclose($data);
fclose($newFile);

// $rowAssoc['Category'] = implode(", ", $matched); // Store matched values as comma separated string
// $rowAssoc['Category'] = ('"' . $matched . '"'); // Store matched values as comma separated string
// $rowAssoc['Category'] = json_encode(implode(", ",array_map(fn($item) => '"' . $item . '"', $matched)));