<?php
function readCsvAssoc($filename)
{
    $file = fopen($filename, "r");
    $header = fgetcsv($file);
    $data = [];

    while (($row = fgetcsv($file)) !== false) {
        $data[] = array_combine($header, $row);
    }
    fclose($file);
    return [$header, $data];
}

[$itemsHeader, $itemsRows] = readCsvAssoc("Items.csv");
$finalData = array_column($itemsRows, null, 'PartNumber');
$finalHeader = array_merge($itemsHeader, ["Description"]);

// Process Descriptions
foreach (readCsvAssoc("Descriptions.csv")[1] as $desc) {
    if ($desc['DescriptionCode'] === 'DES' && isset($finalData[$desc['PartNumber']])) {
        $finalData[$desc['PartNumber']]['Description'] = $desc['Description'];
    }
}

// Process EXPI and build header dynamically
$expiCodes = [];
foreach (readCsvAssoc("EXPI.csv")[1] as $expi) {
    $expiCodes[$expi['EXPICode']] = true;
    if (isset($finalData[$expi['PartNumber']]) && $expi['EXPIValue'] !== '') {
        $finalData[$expi['PartNumber']][$expi['EXPICode']] = $expi['EXPIValue'];
    }
}
$finalHeader = array_merge($finalHeader, array_keys($expiCodes));

// Process Attributes
foreach (readCsvAssoc("Attributes.csv")[1] as $attr) {
    if (isset($finalData[$attr['PartNumber']])) {
        $finalData[$attr['PartNumber']]['Attributes'] = json_encode([$attr['AttributeID'] => $attr['AttributeValue']]);
    }
}
$finalHeader[] = "Attributes";

// Process Packages
$packColumns = [];
foreach (readCsvAssoc("Packages.csv")[1] as $pack) {
    $pn = $pack['PartNumber'];
    foreach ($pack as $col => $val) {
        if ($col !== 'PartNumber' && $val !== '') {
            $packColumns[$col] = true;
            if (isset($finalData[$pn])) {
                $finalData[$pn][$col] = $val;
            }
        }
    }
}
$finalHeader = array_merge($finalHeader, array_keys($packColumns));

// Write output
$output = fopen("New.csv", "w");
fputcsv($output, $finalHeader);
foreach ($finalData as $row) {
    fputcsv($output, array_map(fn($col) => $row[$col] ?? '', $finalHeader));
}
fclose($output);

echo "Done! Optimized New.csv created.";



