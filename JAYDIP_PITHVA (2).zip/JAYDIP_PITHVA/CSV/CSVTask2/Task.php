<?php
// 1
$itemsFile = fopen("Items.csv", "r");
$itemsHeader = fgetcsv($itemsFile);

$finalData = []; // saving evert thing in array with new key value
$finalHeader = $itemsHeader; // adding header for all

while (($row = fgetcsv($itemsFile)) !== false) {
    $item = array_combine($itemsHeader, $row);
    $partNumber = $item['PartNumber'];

    $finalData[$partNumber] = $item; // store by PartNumber
}
fclose($itemsFile);

// 2
$descFile = fopen("Descriptions.csv", "r");
$descHeader = fgetcsv($descFile);

$finalHeader[] = "Description";

while (($row = fgetcsv($descFile)) !== false) {
    $desc = array_combine($descHeader, $row);

    if ($desc['DescriptionCode'] == 'DES') {
        $pn = $desc['PartNumber'];

        if (isset($finalData[$pn])) {
            $finalData[$pn]['Description'] = $desc['Description'];
        }
    }
}
fclose($descFile);

// 3

$expiFile = fopen("EXPI.csv", "r");
$expiHeader = fgetcsv($expiFile);

$expiCodes = [];
while (($row = fgetcsv($expiFile)) !== false) { // expiCode Code
    $expi = array_combine($expiHeader, $row);
    $expiCodes[$expi['EXPICode']] = true;
}

fclose($expiFile);

foreach (array_keys($expiCodes) as $code) {
    $finalHeader[] = $code;
}

foreach ($finalData as &$item) { // Initialize empty values for all rows (important for clean structure)
    foreach (array_keys($expiCodes) as $code) {
        $item[$code] = ''; // default empty
    }
}
unset($item); // break reference

// fill matched values
$expiFile = fopen("EXPI.csv", "r");
fgetcsv($expiFile); // skip header

while (($row = fgetcsv($expiFile)) !== false) {
    $expi = array_combine($expiHeader, $row);

    $pn   = $expi['PartNumber'];
    $code = $expi['EXPICode'];

    if (isset($finalData[$pn]) && $expi['EXPIValue'] != '') {
        $finalData[$pn][$code] = $expi['EXPIValue'];
    }
}

fclose($expiFile);

// 4
$attrFile = fopen("Attributes.csv", "r");
$attrHeader = fgetcsv($attrFile);

$finalHeader[] = "JSON";
$attributes = [];

while (($row = fgetcsv($attrFile)) !== false) {
    $attr = array_combine($attrHeader, $row);
    $pn = $attr['PartNumber'];
    $attributes[$pn][$attr['AttributeID']] = $attr['AttributeValue'];
}
fclose($attrFile);

foreach ($attributes as $pn => $attrData) { // convert to JSON
    if (isset($finalData[$pn])) {
        $finalData[$pn]['JSON'] = json_encode($attrData);
    }
}

// 5
$packFile = fopen("Packages.csv", "r");
$packHeader = fgetcsv($packFile);

$packRows = [];
$nonEmptyCols = [];

while (($row = fgetcsv($packFile)) !== false) {
    $pack = array_combine($packHeader, $row);
    $packRows[] = $pack;

    foreach ($pack as $col => $val) {
        if (!empty($val)) {
            $nonEmptyCols[$col] = true;
        }
    }
}

fclose($packFile);
unset($nonEmptyCols['PartNumber']); // remove PartNumber

foreach (array_keys($nonEmptyCols) as $col) { // add columns to header
    $finalHeader[] = $col;
}

foreach ($finalData as &$item) { // Initialize empty values for ALL rows
    foreach (array_keys($nonEmptyCols) as $col) {
        $item[$col] = ''; // default empty
    }
}
unset($item);

foreach ($packRows as $pack) { // Merge package values
    $pn = $pack['PartNumber'];

    if (isset($finalData[$pn])) {
        foreach (array_keys($nonEmptyCols) as $col) {
            if (!empty($pack[$col])) {
                $finalData[$pn][$col] = $pack[$col];
            }
        }
    }
}

$output = fopen("Task.csv", "w"); // final data saveing
fputcsv($output, $finalHeader);

foreach ($finalData as $row) {
    $orderedRow = [];
    foreach ($finalHeader as $column) {
        $orderedRow[] = $row[$column] ?? '';
    }
    fputcsv($output, $orderedRow);
}

fclose($output);

echo "Done! Task.csv created.";
