<?php
function readCsvAssoc($filename)
{
    $file = fopen($filename, "r");
    $header = fgetcsv($file);
    $data = [];

    while (($row = fgetcsv($file)) !== false) {
        $data[] = array_combine($header, $row);
    }
    fclose($file);
    return [$header, $data];
}

// 1. Header Added

[$itemsHeader, $itemsRows] = readCsvAssoc("Items.csv");
$finalData = [];
$finalHeader = $itemsHeader;
foreach ($itemsRows as $item) {
    $finalData[$item['PartNumber']] = $item;
}

// 2. DESCRIPTIONS

[$descHeader, $descRows] = readCsvAssoc("Descriptions.csv");
$finalHeader[] = "Description";
foreach ($descRows as $desc) {
    if ($desc['DescriptionCode'] === 'DES') {
        $pn = $desc['PartNumber'];
        $finalData[$pn]['Description'] = $desc['Description'];
    }
}

// 3. EXPI

[$expiHeader, $expiRows] = readCsvAssoc("EXPI.csv");
$expiCodes = [];

foreach ($expiRows as $expi) {
    $code = $expi['EXPICode'];
    $pn   = $expi['PartNumber'];

    $expiCodes[$code] = true;

    if (isset($finalData[$pn]) && $expi['EXPIValue'] !== '') {
        $finalData[$pn][$code] = $expi['EXPIValue'];
    }
}

$expiColumns = array_keys($expiCodes);
$finalHeader = array_merge($finalHeader, $expiColumns);

// 4. ATTRIBUTES 

[$attrHeader, $attrRows] = readCsvAssoc("Attributes.csv");

$finalHeader[] = "Attributes";

foreach ($attrRows as $attr) {
    $pn = $attr['PartNumber'];

    if (isset($finalData[$pn])) {
        $jsonData = [];
        $jsonData[$attr['AttributeID']] = $attr['AttributeValue'];
    }
    $finalData[$pn]['Attributes'] = json_encode($jsonData);
}

// 5. PACKAGES

[$packHeader, $packRows] = readCsvAssoc("Packages.csv");

$nonEmptyCols = [];

foreach ($packRows as $pack) {
    foreach ($pack as $col => $val) {
        if ($col !== 'PartNumber' && $val !== '') {
            $nonEmptyCols[$col] = true;
        }
    }
}

$packColumns = array_keys($nonEmptyCols);
$finalHeader = array_merge($finalHeader, $packColumns);

foreach ($packRows as $pack) {
    $pn = $pack['PartNumber'];

    if (isset($finalData[$pn])) {
        foreach ($packColumns as $col) {
            if ($pack[$col] !== '') {
                $finalData[$pn][$col] = $pack[$col];
            }
        }
    }
}

// write final CSV
$output = fopen("Demo.csv", "w");
fputcsv($output, $finalHeader);
foreach ($finalData as $row) {
    $ordered = [];
    foreach ($finalHeader as $col) {
        $ordered[] = $row[$col] ?? '';
    }
    fputcsv($output, $ordered);
}
fclose($output);

echo "Done! Optimized Demo.csv created.";
