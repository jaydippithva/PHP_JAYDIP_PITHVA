<?php

$one = fopen('todos (51k).csv', 'r');
$two = fopen('todos (53k).csv', 'r');

$inOne = fopen('inOne.csv', 'w');

$header =fgetcsv($one);
fputcsv($inOne, $header);

while (($row = fgetcsv($one)) !== false) {
    fputcsv($inOne, $row);
}
fgetcsv($two);//skping file two header
while (($row = fgetcsv($two)) !== false) {
    fputcsv($inOne, $row);
}

echo "Done";

fclose($one);
fclose($two);
fclose($inOne);