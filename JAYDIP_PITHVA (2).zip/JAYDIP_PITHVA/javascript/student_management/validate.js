
document.addEventListener("DOMContentLoaded", function () {

    const fname = document.getElementById("fname");
    const lname = document.getElementById("lname");
    const email = document.getElementById("email");
    const contactno = document.getElementById("contactno");
    const birthdate = document.getElementById("birthdate");
    const course = document.getElementById("course");
    const submitBtn = document.getElementById("submitBtn");

    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    const phonePattern = /^[6-9][0-9]{9}$/;
    const namePattern = /^[A-Za-z]+$/;

    function setError(id, message) {
        document.getElementById(id).innerHTML = message;
    }

    function clearError(id) {
        document.getElementById(id).innerHTML = "";
    }
    
    fname.addEventListener("focusout", function () {
        if (fname.value.trim() === "") {
            setError("efname", "Can Not Be Blank");
        }
    });

    lname.addEventListener("focusout", function () {
        if (lname.value.trim() === "") {
            setError("elname", "Can Not Be Blank");
        }
    });

    email.addEventListener("focusout", function () {
        if (email.value.trim() === "") {
            setError("eemail", "Email required");
        }
    });

    contactno.addEventListener("focusout", function () {
        if (contactno.value.trim() === "") {
            setError("econtactno", "Contact required");
        }
    });

    birthdate.addEventListener("focusout", function () {
        if (birthdate.value === "") {
            setError("ebirthdate", "Birthdate required");
        }
    });

    course.addEventListener("focusout", function () {
        if (course.value === "") {
            setError("ecourse", "Select Course");
        }
    });
   

    // ===== First Name =====
    fname.addEventListener("input", function () {
        let value = fname.value.trim();
        if (value === "") {
            setError("efname", "Can Not Be Blank");
        } else if (!namePattern.test(value)) {
            setError("efname", "Only enter characters");
        } else {
            clearError("efname");
        }
    });

    // ===== Last Name =====
    lname.addEventListener("input", function () {
        let value = lname.value.trim();
        if (value === "") {
            setError("elname", "Can Not Be Blank");
        } else if (!namePattern.test(value)) {
            setError("elname", "Only enter characters");
        } else {
            clearError("elname");
        }
    });

    // ===== Email =====
    email.addEventListener("input", function () {
        let value = email.value.trim();
        if (value === "") {
            setError("eemail", "Email required");
        } else if (!emailPattern.test(value)) {
            setError("eemail", "Invalid Email");
        } else {
            clearError("eemail");
        }
    });

    // ===== Contact =====
    contactno.addEventListener("input", function () {
        let value = contactno.value.trim();
        if (value === "") {
            setError("econtactno", "Contact required");
        } else if (!phonePattern.test(value)) {
            setError("econtactno", "Enter valid 10 digit number");
        } else {
            clearError("econtactno");
        }
    });

    // ===== Birthdate =====
    birthdate.addEventListener("input", function () {
        const today = new Date().toISOString().split('T')[0];
        birthdate.setAttribute('max', today);

        if (birthdate.value === "") {
            setError("ebirthdate", "Birthdate required");
        } else {
            clearError("ebirthdate");
        }
    });

    // ===== Gender =====
    document.querySelectorAll('input[name="gender"]').forEach(function (radio) {
        radio.addEventListener("change", function () {
            clearError("egender");
        });

        // click event added
        radio.addEventListener("click", function () {
            clearError("egender");
        });
    });

    // ===== Course =====
    course.addEventListener("change", function () {
        if (course.value === "") {
            setError("ecourse", "Select Course");
        } else {
            clearError("ecourse");
        }
    });

    // click event added
    course.addEventListener("click", function () {
        if (course.value === "") {
            setError("ecourse", "Select Course");
        }
    });

    // ===== Submit =====
    if (submitBtn) {
        submitBtn.addEventListener("click", function (event) {

            let isValid = true;

            if (fname.value.trim() === "" || !namePattern.test(fname.value.trim())) {
                setError("efname", "Valid First Name required");
                isValid = false;
            }

            if (lname.value.trim() === "" || !namePattern.test(lname.value.trim())) {
                setError("elname", "Valid Last Name required");
                isValid = false;
            }

            if (email.value.trim() === "" || !emailPattern.test(email.value.trim())) {
                setError("eemail", "Valid Email required");
                isValid = false;
            }

            if (contactno.value.trim() === "" || !phonePattern.test(contactno.value.trim())) {
                setError("econtactno", "Valid Contact required");
                isValid = false;
            }

            if (birthdate.value === "") {
                setError("ebirthdate", "Birthdate required");
                isValid = false;
            }

            if (!document.querySelector('input[name="gender"]:checked')) {
                setError("egender", "Select Gender");
                isValid = false;
            }

            if (course.value === "") {
                setError("ecourse", "Select Course");
                isValid = false;
            }

            if (!isValid) {
                event.preventDefault();
            }
            else {
                window.location.reload();
            }
        });
    }

});
