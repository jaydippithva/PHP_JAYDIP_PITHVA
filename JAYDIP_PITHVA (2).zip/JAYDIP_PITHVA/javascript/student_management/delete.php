<?php
require("db.php");
$id = $_GET['id'];
$page = $_GET['page'];
$limit = $_GET['limit'];
$student_deleted = mysqli_fetch_assoc(mysqli_query($con, "SELECT `first_name` from std where `id`=$id"));
if ($student_deleted)
    $student_deleted = "Deleted Student " . $student_deleted['first_name'];
$q = "DELETE FROM std where id=$id";
$row = mysqli_query($con, $q);
if ($row) {
    header("location:index.php?page=$page&limit=$limit&student_delete_result=$student_deleted");
}
