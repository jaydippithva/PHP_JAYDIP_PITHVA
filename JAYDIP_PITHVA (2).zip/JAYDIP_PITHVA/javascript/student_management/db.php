<?php
$con = mysqli_connect("localhost", "root", "", "student_database");
if (!$con) {
    die("Not Conneted!!!" . mysqli_connect_error());
}
?>
