<?php
require("db.php");
require("header.php");

$id = $_GET['id'];
$q = mysqli_fetch_assoc(mysqli_query($con, "SELECT * from course where id=$id"));

if (isset($_POST['submit'])) {
    $cname = trim(strtoupper(($_POST['cname'])));
    $check = mysqli_num_rows(mysqli_query($con, "SELECT * FROM course where `name`='$cname' AND id!=$id"));

    if ($check == 1) {
        $errors['cname'] = "Already Added!!!";
    }
    if (empty($errors)) {
        $q1 = "UPDATE course set `name`='$cname' where id=$id";
        $row = mysqli_query($con, $q1);
        if ($row) {
            header("location:courseview.php?r=success");
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="container mt-4">
    <h2 class="mb-4">Course Edit</h2>

    <form method="post" id="course_form">

        <div class="mb-3">
            <label class="form-label">Course Name</label>
            <input type="text" class="form-control" id="cname" name="cname" value=<?= $q['name']; ?>>
            <div class="text-danger">
                <label id="ecname"></label>
                <?= $errors['cname'] ?? '' ?>
            </div>
        </div>
        <div class="mb-3">
            <button type="submit" id="csubmitBtn" name="submit">Submit</button>
           
        </div>
    </form>
    <script src="course_validate.js"></script>

</body>

</html>