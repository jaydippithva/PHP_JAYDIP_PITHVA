document.addEventListener("DOMContentLoaded", function () {

    let cname = document.getElementById("cname");
    let submitBtn = document.getElementById("csubmitBtn");


    cname.addEventListener("input", function () {
        let value = cname.value.trim();
        console.log(value);
            //event.preventDefault();

        if (value === "") {
            document.getElementById("ecname").innerHTML = "Can Not Be Blank";
        }
        else if (!/^[A-Za-z]+$/.test(value)) {
            document.getElementById("ecname").innerHTML = "Only enter characters";
        }
        else {
            document.getElementById("ecname").innerHTML = "";
        }

    });
    if(submitBtn)
    {
         submitBtn.addEventListener("click", function (event) {
            // event.preventDefault();
            let isValid = true;

            // Validate First Name
            let cnameValue = cname.value.trim();
            if (cnameValue === "") {
                document.getElementById("ecname").innerHTML = "Can Not Be Blank";
                isValid = false;
            } else if (!/^[A-Za-z]+$/.test(cnameValue)) {
                document.getElementById("ecname").innerHTML = "Only enter characters";
                isValid = false;
            } else {
                document.getElementById("ecname").innerHTML = "";

            }

            if (!isValid) {
                event.preventDefault();  
            }
        });
    }
});

