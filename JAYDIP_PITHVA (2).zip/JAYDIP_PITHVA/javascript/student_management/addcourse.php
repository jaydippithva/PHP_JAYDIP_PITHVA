<?php
require("db.php");
require("header.php");


if (isset($_POST['submit'])) {
    $cname = trim(strtoupper($_POST['cname']));
    $row = mysqli_num_rows(mysqli_query($con, "SELECT * FROM course where `name`='$cname'"));

 
    if ($row == 1)
        $errors['ecname'] = "Already Added!!!";


    if (empty($errors)) {
        $q = "INSERT INTO course(`name`) values('$cname')";
        $row = mysqli_query($con, $q);
        if ($row) {
            echo "<script>window.location='courseview.php?r=course_added';</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="container mt-4">
    <h2 class="mb-4">Add Course</h2>
    <form method="post" id="course_form" >
        <div class="mb-3">
            <label class="form-label">Course Name</label>
            <input type="text" class="form-control" name="cname" id="cname">
            <div class="text-danger">
                <label id="ecname"></label>
                <?= $errors['ecname'] ?? '' ?>

            </div>
        </div>
        <div class="mb-3">
            <button type="submit" id="csubmitBtn" name="submit">Submit</button>
        </div>

    </form>
    <script src="course_validate.js"></script>
</body>

</html>