console.log("sdgff");
// let fname=document.getElementById("fname").value;
// let lname=document.getElementById("lanme").value;
// let email=document.getElementById("email").value;
// let contactno=document.getElementById("contactno").value;
// let birthday=document.getElementById("birthday").value;
// let gender=document.getElementById("gender").value;
// let course=document.getElementById("course").value;

// // if(fname === "")
// // {
// //     document.getElementById("efname").innerHTML="First Name Can no tBe Blank";
// // }