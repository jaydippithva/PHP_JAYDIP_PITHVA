<?php
require("db.php");
require("header.php");

$limit = 5;
$errors = [];

if (isset($_GET['student_delete_result'])) {
    echo $_GET['student_delete_result'];
}

if (isset($_GET['user_update'])) {
    echo $_GET['user_update'];
}

if (isset($_GET['limit'])) {
    if ($_GET['limit'] == "all") {
        $limit = 0;
    } else {
        $limit = (int)$_GET['limit'];
    }
}



$allowed_columns = ['id', 'first_name', 'last_name', 'email', 'course_id', 'gender'];
$order_column = "name";      // default column
$order_direction = "ASC";  // default order

if (isset($_GET['sort']) && in_array($_GET['sort'], $allowed_columns)) {
    $order_column = $_GET['sort'];
}

if (isset($_GET['order']) && $_GET['order'] == "DESC") {
    $order_direction = "DESC";
} else {
    $order_direction = "ASC";
}



$search = "";
$where = "";

if (isset($_GET['search']) && $_GET['search'] != "") {
    $search = $_GET['search'];
    $where = "WHERE std.first_name LIKE '%$search%'";
}

$count_query = "SELECT COUNT(*) as total 
                FROM std 
                INNER JOIN course ON std.course_id = course.id 
                $where  ORDER BY $order_column $order_direction";

$count_result = mysqli_query($con, $count_query);
$count_row = mysqli_fetch_assoc($count_result);
$total_records = $count_row['total'];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = ($page <= 0) ? 1 : $page;

if ($limit > 0) {
    $start = ($page - 1) * $limit;

    $query = "SELECT std.*, course.name AS course_name
              FROM std
              INNER JOIN course ON std.course_id = course.id
              $where  ORDER BY $order_column $order_direction
              LIMIT $start, $limit";
} else {
    $query = "SELECT std.*, course.name AS course_name
              FROM std
              INNER JOIN course ON std.course_id = course.id
              $where  ORDER BY $order_column $order_direction";
}

$result1 = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Student View</title>

</head>

<body class="container mt-4">
    <?php
    if (isset($_POST['submit'])) {

        $fname = trim($_POST['fname']);
        $lname = trim($_POST['lname']);
        $email = trim($_POST['email']);
        $contactno = trim($_POST['contactno']);
        $birthdate = $_POST['birthdate'];
        $gender = $_POST['gender'] ?? '';
        $course = $_POST['course'] ?? '';

        // ===== Server Side Validation =====
        if ($course === "") {
            $errors['course'] = "seledct course";
        }

        if ($gender === "") {
            $errors['gender'] = "Please select gender";
        }

        $fetch_email = mysqli_num_rows(mysqli_query($con, "SELECT * From std where `email`='$email'"));

        if ($fetch_email == 1) {
            $errors['email'] = "Email Already Register";
        }
        $fetch_contact = mysqli_num_rows(mysqli_query($con, "SELECT * From std where `contact_number`='$contactno'"));

        if ($fetch_contact == 1) {
            $errors['contactno'] = "Contact Already Register";
        }
        // Insert only if no errors
        if (empty($errors)) {

            $stmt = mysqli_query($con, "INSERT INTO std 
        (first_name, last_name, email, contact_number, birthdate, gender, course_id)
        VALUES('$fname','$lname','$email','$contactno','$birthdate','$gender','$course')");

            if ($stmt) {
                echo "<script>alert('Student Added Successfully');window.location.reload();</script>";
            } else {
                echo "<script>alert('Database Error');</script>";
            }
        }
    }
    ?>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="false">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add Student</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="form" method="post">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" id="fname">
                            <div class="text-danger">
                                <label id="efname"></label>
                                <?= $errors['fname'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" id="lname">
                            <div class="text-danger">
                                <label id="elname"></label>

                                <?= $errors['lname'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email">
                            <div class="text-danger">
                                <label id="eemail"></label>

                                <?= $errors['email'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" name="contactno" id="contactno">
                            <div class="text-danger">
                                <label id="econtactno"></label>

                                <?= $errors['contactno'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="birthdate" class="form-label">Birthdate</label>
                            <input type="date" class="form-control" name="birthdate" id="birthdate" max="">
                            <div class="text-danger">
                                <label id="ebirthdate"></label>

                                <?= $errors['birthdate'] ?? '' ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Gender</label>

                            <div class="form-check">
                                <input class="form-check-input" type="radio"
                                    name="gender" value="Male" id="male">
                                <label class="form-check-label" for="male">
                                    Male
                                </label>
                            </div>

                            <div class="form-check">
                                <input class="form-check-input" type="radio"
                                    name="gender" value="Female" id="female">
                                <label class="form-check-label" for="female">
                                    Female
                                </label>
                            </div>

                            <div class="text-danger">
                                <label id="egender"></label>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Course</label>

                            <select name="course" class="form-select" id="course">
                                <option value="" selected>-- Select Course --</option>
                                <?php
                                $q = "SELECT * FROM course";
                                $row1 = mysqli_query($con, $q);
                                while ($res1 = mysqli_fetch_assoc($row1)) {
                                ?>
                                    <option value="<?= $res1['id']; ?>"><?= $res1['name']; ?></option>
                                <?php } ?>
                            </select>
                            <div class="text-danger">
                                <label id="ecourse"></label>

                                <?= $errors['course'] ?? '' ?>
                            </div>
                        </div>
                        <button type="submit" id="submitBtn" name="submit">Submit</button>
                    </form>
                    <script src="validate.js"></script>
                </div>
            </div>
        </div>
    </div>
    <?= $errors['email'] ?? '' ?>

    <h2 class="mb-4">Student Management</h2>

    <div class="mb-3">
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Insert Student
        </button>
        <a href="courseview.php" class="btn btn-info">Course View</a>
    </div>

    <form method="GET" class="row mb-3">

        <div class="col-md-4">
            <input type="text" name="search" value="<?= $search ?>"
                class="form-control" placeholder="Search by First Name">
        </div>

        <div class="col-md-3">
            <select name="limit" class="form-select">
                <option value="5" <?= ($limit == 5) ? 'selected' : '' ?>>First 5 Records</option>
                <option value="10" <?= ($limit == 10) ? 'selected' : '' ?>>First 10 Records</option>
                <option value="all" <?= ($limit == 0) ? 'selected' : '' ?>>All Records</option>
            </select>
        </div>

        <div class="col-md-2">
            <button type="submit" class="btn btn-dark">Apply</button>
        </div>

        <table class="table table-bordered table-striped mt-3">
            <?php

            $new_order = ($order_direction == "ASC") ? "DESC" : "ASC";
            ?>
            <tr class="table-dark">
                <th>
                    <?php $order = ($order_direction == "ASC") ? "DESC" : "ASC"; ?>

                    <a class="text-decoration-none text-white" href="idorder=<?= $order ?>">ID</a>
                </th>
                <th>
                    <a class="text-decoration-none text-white">
                        First Name
                    </a>
                </th>
                <th>
                    <a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=last_name&order=<?= $new_order ?>">
                        Last Name
                    </a>
                </th>
                <th><a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=email&order=<?= $new_order ?>">
                        Email
                    </a>
                </th>
                <th>
                    Contact Number
                </th>
                <th>
                    Birthdate
                </th>
                <th><a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=gender&order=<?= $new_order ?>">
                        Gender
                    </a>
                </th>
                <th><a class="text-decoration-none text-white" href="?page=<?= $page ?>&limit=<?= $limit ?>&search=<?= $search ?>&sort=course_name&order=<?= $new_order ?>">
                        Course
                    </a></th>
                <th>Actions</th>
            </tr>

            <?php
            if ($order_direction == "DESC") {
                $idnumber = $total_records - (($page - 1) * $limit);
            } else {
                $idnumber = (($page - 1) * $limit) + 1;
            }

            while ($row = mysqli_fetch_assoc($result1)) {
            ?>

                <tr>
                    <td><?= $idnumber++ ?></td>
                    <td><?= $row['first_name'] ?></td>
                    <td><?= $row['last_name'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['contact_number'] ?></td>
                    <td><?= $row['birthdate'] ?></td>
                    <td><?= $row['gender'] ?></td>
                    <td><?= $row['course_name'] ?></td>
                    <td>
                        <a href="view.php?id=<?= $row['id'] ?>&page=<?= $page ?>&limit=<?= $limit ?>" class="btn btn-sm btn-primary">View</a>
                        <a href="edit.php?id=<?= $row['id'] ?>&page=<?= $page ?>&limit=<?= $limit ?>" class="btn btn-sm btn-warning">Edit</a>
    
                        <a href="delete.php?id=<?= $row['id'] ?>&page=<?= $page ?>&limit=<?= $limit ?>" onclick="return confirm('Are you sure you want to delete this record?');" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>

            <?php } ?>

        </table>
    </form>
    <?php
    if ($limit > 0) {
        $total_pages = ceil($total_records / $limit);

        echo '<nav><ul class="pagination">';

        for ($i = 1; $i <= $total_pages; $i++) {
            $active = ($i == $page) ? "active" : "";
            echo "<li class='page-item $active'>
                <a class='page-link' 
                href='?page=$i&limit=$limit&search=$search'>$i</a>
              </li>";
        }

        echo '</ul></nav>';
    }
    ?>

</body>

</html>