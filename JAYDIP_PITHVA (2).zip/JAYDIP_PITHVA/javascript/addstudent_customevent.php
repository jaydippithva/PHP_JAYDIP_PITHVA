<!DOCTYPE html>
<html>
<body>
<form>
    <input type="text" id="input">
    <button type="button" id="add">Add Student</button>
    <label id="error"></label>
    <p id="output" style="color:red; text-align:right;"></p>
</form>

<script>

const button = document.getElementById("add");

// Custom Event function
function addstudent(sname){
    return new CustomEvent("newevent",{
        detail:{
            name:sname
        }
    });
}

// Listen event
document.addEventListener("newevent",function(event){
    document.getElementById("error").innerHTML =
        "Student Added: " + event.detail.name;
});

// Click event
button.addEventListener("click",function(){

    let sname = document.getElementById("input").value;

    if(sname === ""){
        document.getElementById("error").innerHTML =
            "Please enter some text";
    }
    else if(!isNaN(sname)){
        document.getElementById("error").innerHTML =
            "please enter only character";
    }
    else {
        const event1 = addstudent(sname);
        document.dispatchEvent(event1);
    }

});

</script>

</body>
</html>