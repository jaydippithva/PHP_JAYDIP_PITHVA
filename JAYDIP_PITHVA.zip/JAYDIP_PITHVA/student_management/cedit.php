<?php
require("db.php");
require("header.php");


$id = $_GET['id'];
$q = mysqli_fetch_assoc(mysqli_query($con, "SELECT * from course where id=$id"));

if(isset($_POST['cedit']))
    {
        $cname=trim(strtoupper(($_POST['name'])));
        $check=mysqli_num_rows(mysqli_query($con,"SELECT * FROM course where `name`='$cname' AND id!=$id"));
   
        if(empty($cname))
            {
                $errors['name'] = "Enter  Course ";
            }
        elseif($check=="1")
            {   
                $errors['name'] = "Already Added!!!";
            }

        if(empty($errors))
            {
                $q1="UPDATE course set `name`='$cname' where id=$id";
                $row=mysqli_query($con,$q1);
                if($row)
                    {
                        header("location:courseview.php");
                    }
            }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="container mt-4">
    <h2 class="mb-4">Course Edit</h2>

    <form method="POST">
       
        <div class="mb-3">
            <label class="form-label">Course Name</label>
            <input type="text" class="form-control" name="name" value=<?= $q['name']; ?>>
            <div class="text-danger">
                <?= $errors['name'] ?? '' ?>
            </div>
        </div>
        <div class="mb-3">
            <button type="submit" name="cedit" class="btn btn-primary">Submit</button>

        </div>
    </form>
</body>

</html>