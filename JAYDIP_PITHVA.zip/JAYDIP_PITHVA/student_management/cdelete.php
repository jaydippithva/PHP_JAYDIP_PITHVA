<?php
    require("db.php");
    require("header.php");

    $id=$_GET['id'];
    $q="DELETE from course where id=$id";
    $row=mysqli_query($con,$q);
    if($row)
        {
            header("location:courseview.php");
        }
?>