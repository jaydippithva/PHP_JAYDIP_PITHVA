<?php
require("db.php");
require("header.php");



    if(isset($_POST['addcourse']))
        {
            $cname=trim(strtoupper($_POST['cname']));
            $row=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM course where `name`='$cname'"));

            if(empty($cname))
                $errors['cname'] = "Course Name is required";
            elseif(!preg_match("/^[A-Za-z ]+$/", $cname))
                $errors['cname'] = "Only letters allowed";
            elseif($cname==$row['name'])
                $errors['cname'] = "Already Added!!!";


            if(empty($errors))
                {
                    $q="INSERT INTO course(`name`) values('$cname')";
                    $row=mysqli_query($con,$q);
                    if($row)
                        {
                            header("location:courseview.php");
                        }
                }

        }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="container mt-4">
    <h2 class="mb-4">Add Course</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Course Name</label>
            <input type="text" class="form-control" name="cname">
            <div class="text-danger">
                <?= $errors['cname'] ?? '' ?>
            </div>
        </div>
        <div class="mb-3">
            <button type="submit" name="addcourse" class="btn btn-primary">Submit</button>
        </div>
    </form>
</body>
</html>
