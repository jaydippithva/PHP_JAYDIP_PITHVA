<?php
require("db.php");
require("header.php");

$id = $_GET['id'];

$q = "SELECT std.*,course.name as course_name FROM std inner join course on std.course_id=course.id where std.id=$id";
$row = mysqli_fetch_assoc(mysqli_query($con, $q));


$errors = [];

if (isset($_POST['register'])) {

    //echo "hell";exit;
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $contactno = trim($_POST['contactno']);
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'] ?? '';
    $course = $_POST['course'] ?? '';

    if (empty($fname))
        $errors['fname'] = "First Name is required";
    elseif (!preg_match("/^[A-Za-z ]+$/", $fname))
        $errors['fname'] = "Only letters allowed";

    if (empty($lname))
        $errors['lname'] = "Last Name is required";



    if (empty($email))
        $errors['email'] = "Email is required";
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors['email'] = "Invalid email format";
    elseif (!empty($email)) {
        $eq = "SELECT `email` from `std` where `email`='$email' and id!=$id";
        $erow = (mysqli_num_rows(mysqli_query($con, $eq)));
        if ($erow == 1)
            $errors['email'] = "Email Already Registered!!!";
    }

    if (empty($contactno))
        $errors['contactno'] = "Contact number required";
    elseif (!preg_match("/^[6-9][0-9]{9}$/", $contactno))
        $errors['contactno'] = "Enter valid 10 digit number & Indian Number";

    if (empty($birthdate))
        $errors['birthdate'] = "Birthdate required";

    if (empty($gender))
        $errors['gender'] = "Select gender";

    if (empty($course))
        $errors['course'] = "Select course";

    if (empty($errors)) {
        $update="UPDATE `std` SET 
            `first_name`='$fname',`last_name`='$lname',`email`='$email',
            `contact_number`='$contactno',`birthdate`='$birthdate',`gender`='$gender',`course_id`='$course' WHERE `id`=$id";
        $updaterow=mysqli_query($con,$update);
        if($updaterow)
            {
                header("location:index.php");
            }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="container mt-4">
    <table class="table table-bordered table-striped mt-3">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">First Name</label>
                <input type="text" class="form-control" name="fname" value="<?= $row['first_name'] ?>">
                <div class="text-danger">
                    <?= $errors['fname'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Last Name</label>
                <input type="text" class="form-control" name="lname" value="<?= $row['last_name'] ?>">
                <div class="text-danger">
                    <?= $errors['lname'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" name="email" value="<?= $row['email'] ?>">
                <div class="text-danger">
                    <?= $errors['email'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Contact Number</label>
                <input type="tel" class="form-control" name="contactno" value="<?= $row['contact_number'] ?>">
                <div class="text-danger">
                    <?= $errors['contactno'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Birthdate</label>
                <input type="date" class="form-control" name="birthdate" value="<?= $row['birthdate'] ?>">
                <div class="text-danger">
                    <?= $errors['birthdate'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Gender</label>

                <div class="form-check">
                    <input class="form-check-input" type="radio"
                        name="gender" value="Male" <?= ($row['gender'] == 'Male') ? 'checked' : ''; ?> id="male" $mchecked>
                    <label class="form-check-label" for="male">
                        Male
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio"
                        name="gender" value="Female" <?= ($row['gender'] == 'Female') ? 'checked' : ''; ?> id="female" $fchecked>
                    <label class="form-check-label" for="female">
                        Female
                    </label>
                </div>
                <div class="text-danger">
                    <?= $errors['gender'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Course</label>

                <select name="course" class="form-select">
                    <option value="" disabled selected>-- Select Course --</option>
                    <?php
                    $q = "SELECT * FROM course";
                    $row1 = mysqli_query($con, $q);
                    while ($res1 = mysqli_fetch_assoc($row1)) {
                    ?>
                        <option value="<?= $res1['id']; ?>" <?= (isset($row['course_id']) && $row['course_id'] == $res1['id']) ? 'selected' : ''; ?>><?= $res1['name']; ?></option>
                    <?php } ?>
                </select>
                <div class="text-danger">
                    <?= $errors['course'] ?? '' ?>
                </div>
            </div>
            <button type="submit" name="register" class="btn btn-primary">Submit</button>
        </form>
    </table>
</body>

</html>