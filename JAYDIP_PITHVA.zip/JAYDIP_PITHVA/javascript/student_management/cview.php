<?php
    require("db.php");
    require("header.php");

    $id=$_GET['id'];

    $q=mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM course where id=$id"));


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="container mt-4">
    <table class="table table-bordered table-striped mt-3">
            <tr class="table-dark">
                <th>Course Name</th>
            </tr>
            <tr>
                <td><?= $q['name'] ?></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                <a href="courseview.php" class="btn btn-sm btn-primary">Back</a></td>
            </tr>

    </table>
</body>
</html>