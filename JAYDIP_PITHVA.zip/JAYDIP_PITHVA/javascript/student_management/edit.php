<?php
require("db.php");
require("header.php");

$id = $_GET['id'];

$q = "SELECT std.*,course.name as course_name FROM std inner join course on std.course_id=course.id where std.id=$id";
$row = mysqli_fetch_assoc(mysqli_query($con, $q));

$page = $_GET['page'];
$limit = $_GET['limit'];
$errors = [];
?>
<?php
    if (isset($_POST['submit'])) {

        // echo "hell";exit;
        $fname = trim($_POST['fname']);
        $lname = trim($_POST['lname']);
        $email = trim($_POST['email']);
        $contactno = trim($_POST['contactno']);
        $birthdate = $_POST['birthdate'];
        $gender = $_POST['gender'] ?? '';
        $course = $_POST['course'] ?? '';

        if (!empty($email)) {
            $eq = "SELECT `email` from `std` where `email`='$email' and id!=$id";
            $erow = (mysqli_num_rows(mysqli_query($con, $eq)));
            if ($erow == 1)
                $errors['email'] = "Email Already Registered!!!";

            $fetch_contact = mysqli_num_rows(mysqli_query($con, "SELECT * From std where `contact_number`='$contactno' and id!=$id"));

            if ($fetch_contact == 1) {
                $errors['contactno'] = "Contact Already Register";
            }
        }
        if (empty($errors)) {
            $update = "UPDATE `std` SET 
            `first_name`='$fname',`last_name`='$lname',`email`='$email',
            `contact_number`='$contactno',`birthdate`='$birthdate',`gender`='$gender',`course_id`='$course' WHERE `id`=$id";
            $updaterow = mysqli_query($con, $update);
            if ($updaterow) {
               header("location:index.php?page=$page&limit=$limit'&user_update=updated");
            } else {
                echo "<script>alert('Something Went Wrong');</script>";
            }
        }
    }

    ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body class="container mt-4">
    <table class="table table-bordered table-striped mt-3">
        <form id="form" method="post">
            <div class="mb-3">
                <label class="form-label">First Name</label>
                <input type="text" class="form-control" name="fname" id="fname" value="<?= $row['first_name'] ?>">
                <div class="text-danger">
                    <label id="efname"></label>
                    <?= $errors['fname'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Last Name</label>
                <input type="text" class="form-control" name="lname" id="lname" value="<?= $row['last_name'] ?>">
                <div class="text-danger">
                    <label id="elname"></label>
                    <?= $errors['lname'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" name="email" id="email" value="<?= $row['email'] ?>">
                <div class="text-danger">
                    <label id="eemail"></label>

                    <?= $errors['email'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Contact Number</label>
                <input type="tel" class="form-control" name="contactno" id="contactno" value="<?= $row['contact_number'] ?>">
                <div class="text-danger">
                    <label id="econtactno"></label>

                    <?= $errors['contactno'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Birthdate</label>
                <input type="date" class="form-control" name="birthdate" id="birthdate" max="" value="<?= $row['birthdate'] ?>">
                <div class="text-danger">
                    <label id="ebirthdate"></label>

                    <?= $errors['birthdate'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Gender</label>

                <div class="form-check">
                    <input class="form-check-input" type="radio"
                        name="gender" value="Male" id="male" <?= ($row['gender'] == 'Male') ? 'checked' : ''; ?> id="male" $mchecked>
                    <label class="form-check-label" for="male">
                        Male
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio"
                        name="gender" value="Female" id="female" <?= ($row['gender'] == 'Female') ? 'checked' : ''; ?> id="female" $fchecked>
                    <label class="form-check-label" for="female">
                        Female
                    </label>
                </div>
                <div class="text-danger">
                    <label id="egender"></label>

                    <?= $errors['gender'] ?? '' ?>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label">Course</label>

                <select name="course" class="form-select" id="course">
                    <option value="" selected>-- Select Course --</option>
                    <?php
                    $q = "SELECT * FROM course";
                    $row1 = mysqli_query($con, $q);
                    while ($res1 = mysqli_fetch_assoc($row1)) {
                    ?>
                        <option value="<?= $res1['id']; ?>" <?= (isset($row['course_id']) && $row['course_id'] == $res1['id']) ? 'selected' : ''; ?>><?= $res1['name']; ?></option>
                    <?php } ?>
                </select>
                <div class="text-danger">
                    <label id="ecourse"></label>

                    <?= $errors['course'] ?? '' ?>
                </div>
            </div>
            <button type="submit" id="submitBtn" name="submit">Submit</button>

        </form>
        <script src="validate.js"></script>

    </table>
</body>

</html>