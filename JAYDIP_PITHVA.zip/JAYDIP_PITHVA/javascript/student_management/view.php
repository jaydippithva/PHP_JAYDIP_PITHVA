<?php
    require("db.php");
    require("header.php");
    $id=$_GET['id'];
    $page=$_GET['page'];
    $limit=$_GET['limit'];


    $q="SELECT std.*,course.name as course_name FROM std inner join course on std.course_id=course.id where std.id=$id";
    $row=mysqli_fetch_assoc(mysqli_query($con,$q));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="container mt-4">
    <table class="table table-bordered table-striped mt-3">
            <tr class="table-dark">
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Birthdate</th>
                <th>Gender</th>
                <th>Course</th>
            </tr>
            <tr>
                <td><?= $row['id'];?></td>
                <td><?= $row['first_name'];?>
                <td><?= $row['last_name'];?>
                <td><?= $row['email'];?>
                <td><?= $row['contact_number'];?>
                <td><?= $row['birthdate'];?>
                <td><?= $row['gender'];?>
                <td><?= $row['course_name'];?>
            </tr>
            <tr>
                <td>
                    <a href="index.php?page=<?= $page ?>&limit=<?= $limit ?>" class="btn btn-sm btn-primary">Back</a>
                </td>
            </tr>
</table>
</body>
</html>



