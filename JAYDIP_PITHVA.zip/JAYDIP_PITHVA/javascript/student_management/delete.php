<?php
require("db.php");
$id = $_GET['id'];
$page = $_GET['page'];
$limit = $_GET['limit'];
$q = "DELETE FROM std where id=$id";
$row = mysqli_query($con, $q);
if ($row) {
    echo "<script>alert('Student deleted successfully'); window.location='index.php?page=$page&limit=$limit';</script>";
}
