
document.addEventListener("DOMContentLoaded", function () {

    let fname = document.getElementById("fname");
    let lname = document.getElementById("lname");
    let email = document.getElementById("email");
    let contactno = document.getElementById("contactno");
    let birthdate = document.getElementById("birthdate");
    let course = document.getElementById("course");
    let submitBtn = document.getElementById("submitBtn");
    // let editsubmitBtn = document.querySelector('button[name="register"]');

    fname.addEventListener("input", function () {
        let value = fname.value.trim();

        if (value === "") {
            document.getElementById("efname").innerHTML = "Can Not Be Blank";
        }
        else if (!/^[A-Za-z]+$/.test(value)) {
            document.getElementById("efname").innerHTML = "Only enter characters";
        }
        else {
            document.getElementById("efname").innerHTML = "";
        }

    });




    fname.addEventListener("click", function () {
        let value = fname.value.trim();

        if (value === "") {
            document.getElementById("efname").innerHTML = "Can Not Be Blank";
        }
    });
    lname.addEventListener("click", function () {
        let value = lname.value.trim();
        if (value === "") {
            document.getElementById("elname").innerHTML = "Can Not Be Blank";
        }
    });
    email.addEventListener("click", function () {
        let value = email.value.trim();
        let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

        if (value === "") {
            document.getElementById("eemail").innerHTML = "Email required";
        }
    });
    contactno.addEventListener("click", function () {
        let value = contactno.value.trim();
        let phonePattern = /^[6-9][0-9]{9}$/;

        if (value === "") {
            document.getElementById("econtactno").innerHTML = "Contact required";
        }
    });
    birthdate.addEventListener("click", function () {
        let value = birthdate.value.trim();
        let bdate = new Date();

        const today = new Date();
        const formattedToday = today.toISOString().split('T')[0];

        document.getElementById('birthdate').setAttribute('max', formattedToday);
        if (value === "") {
            document.getElementById("ebirthdate").innerHTML = "Birthdate required";
        }
    });
    

    // ===== Last Name =====
    lname.addEventListener("input", function () {
        let value = lname.value.trim();
        if (value === "") {
            document.getElementById("elname").innerHTML = "Can Not Be Blank";
        } else if (!isNaN(value)) {
            document.getElementById("elname").innerHTML = "Only enter characters";
        } else {
            document.getElementById("elname").innerHTML = "";
        }
    });
    // ===== Email =====
    email.addEventListener("input", function () {
        let value = email.value.trim();
        let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

        if (value === "") {
            document.getElementById("eemail").innerHTML = "Email required";
        } else if (!emailPattern.test(value)) {
            document.getElementById("eemail").innerHTML = "Invalid Email";
        } else {
            document.getElementById("eemail").innerHTML = "";
        }
    });
    // ===== Contact Number =====
    contactno.addEventListener("input", function () {
        let value = contactno.value.trim();
        let phonePattern = /^[6-9][0-9]{9}$/;

        if (value === "") {
            document.getElementById("econtactno").innerHTML = "Contact required";
        } else if (!phonePattern.test(value)) {
            document.getElementById("econtactno").innerHTML = "Enter valid 10 digit number";
        } else {
            document.getElementById("econtactno").innerHTML = "";
        }
    });

    // ===== Birthdate =====
    birthdate.addEventListener("input", function () {
        let value = birthdate.value.trim();
        let bdate = new Date();

        const today = new Date();
        const formattedToday = today.toISOString().split('T')[0];

        document.getElementById('birthdate').setAttribute('max', formattedToday);
        if (value === "") {
            document.getElementById("ebirthdate").innerHTML = "Birthdate required";
        }
        else if (new Date(value) > bdate) {
            document.getElementById("ebirthdate").innerHTML = "Birthdate cannot be in the future";

        }
        else {
            document.getElementById("ebirthdate").innerHTML = "";
        }
    });
    // ===== Gender =====

    let genderRadios = document.getElementsByName("gender");

    genderRadios.forEach(function (radio) {
        radio.addEventListener("change", function () {
            const selected = document.querySelector('input[name="gender"]:checked');
            if (!selected) {
                document.getElementById("egender").innerHTML = "Select Gender";
            } else {
                document.getElementById("egender").innerHTML = "";
            }
        });
    });

    // ===== Course =====
    course.addEventListener("change", function () {
        let value = course.value.trim();
        if (value === "") {
            document.getElementById("ecourse").innerHTML = "Select Course";
        } else {
            document.getElementById("ecourse").innerHTML = "";
        }
    });

    // ===== Submit Button =====
    if (submitBtn) {
        submitBtn.addEventListener("click", function (event) {
            //event.preventDefault();
            let isValid = true;

            // Validate First Name
            let fnameValue = fname.value.trim();
            if (fnameValue == "") {
                document.getElementById("efname").innerHTML = "Can Not Be Blank";
                isValid = false;
            } else if (!/^[A-Za-z]+$/.test(fnameValue)) {
                document.getElementById("efname").innerHTML = "Only enter characters";
                isValid = false;
            } else {
                document.getElementById("efname").innerHTML = "";

            }

            // Validate Last Name
            let lnameValue = lname.value.trim();
            if (lnameValue === "") {
                document.getElementById("elname").innerHTML = "Can Not Be Blank";
                isValid = false;
            } else if (!isNaN(lnameValue)) {
                document.getElementById("elname").innerHTML = "Only enter characters";
                isValid = false;
            } else {
                document.getElementById("elname").innerHTML = "";

            }

            // Validate Email
            let emailValue = email.value.trim();
            let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            if (emailValue === "") {
                document.getElementById("eemail").innerHTML = "Email required";
                isValid = false;
            } else if (!emailPattern.test(emailValue)) {
                document.getElementById("eemail").innerHTML = "Invalid Email";
                isValid = false;
            } else {
                document.getElementById("eemail").innerHTML = "";

            }

            // Validate Contact Number
            let contactValue = contactno.value.trim();
            let phonePattern = /^[6-9][0-9]{9}$/;
            if (contactValue === "") {
                document.getElementById("econtactno").innerHTML = "Contact required";
                isValid = false;
            } else if (!phonePattern.test(contactValue)) {
                document.getElementById("econtactno").innerHTML = "Enter valid 10 digit number";
                isValid = false;
            } else {
                document.getElementById("econtactno").innerHTML = "";

            }

            // Validate Birthdate
            const today = new Date();
            const formattedToday = today.toISOString().split('T')[0];

            document.getElementById('birthdate').setAttribute('max', formattedToday);
            let birthdateValue = birthdate.value.trim();
            let bdate = new Date();
            if (birthdateValue === "") {
                document.getElementById("ebirthdate").innerHTML = "Birthdate required";
                isValid = false;
            }
            else {
                document.getElementById("ebirthdate").innerHTML = "";

            }

            // Validate Gender
            const selectedGender = document.querySelector('input[name="gender"]:checked');
            if (!selectedGender) {
                document.getElementById("egender").innerHTML = "Select Gender";
                isValid = false;
            } else {
                document.getElementById("egender").innerHTML = "";

            }

            // Validate Course
            let courseValue = course.value.trim();
            if (courseValue === "") {
                document.getElementById("ecourse").innerHTML = "Select Course";
                isValid = false;
            } else {
                document.getElementById("ecourse").innerHTML = "";
            }

            if (!isValid) {
                event.preventDefault();  // stop form submission
            }
            // console.log(document.getElementById("form"));
            // let form = document.getElementById("form");
            // form.submit();   
        });
    }
});
