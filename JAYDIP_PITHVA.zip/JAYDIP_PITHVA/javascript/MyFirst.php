<html>
<body>
<form action="">
    <h1>My First Web Page</h1>
    <input type="text" id="click" >
    <input type="button" onclick="number()" value="Submit">
    <p id="number"></p>
</form>
<script>
    function number()
    {
        var no=document.getElementById("click").value;
        var output="";
        for(let i=1;i<=no;i++)
        {
            output += i + "<br>";
        }
        document.getElementById("number").innerHTML=output;
    }
</script>
</body>
</html>