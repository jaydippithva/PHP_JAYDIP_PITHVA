<button id="btn">Click Me</button>
<p id="output"></p>
<script>
const button = document.getElementById("btn");

const myEvent = new Event("myEvent");

button.addEventListener("myEvent", function() {
    document.getElementById("output").innerHTML="";
    for(i=0;i<5;i++)
        document.getElementById("output").innerHTML += i+1;

});

button.addEventListener("click", function() {
    button.dispatchEvent(myEvent);
});
</script>