<?php
$str = "Solitari, Anelli, Bracciali, Ciondoli, Collane, Collane E Pendenti,  Diamanti, Fedi E Fedine, Fermasoldi, Gemelli, Girocolli, Orecchini, Orologi, Portachiavi, Solitari, Spille, Charms, Componenti, OROLOGI, Girocolli Punto Luce, Girocolli con Diamanti, Girocolli con Pietre di Colore, Girocolli con Croci, Girocolli con Perle, Girocolli in Oro, Fili di Perle, Catene in Oro, Catene Uomo in Oro, Catene Donna in Oro, Collane Rosari, Bracciali Tennis, Bracciali con Diamanti, Bracciali Perle, Bracciali Oro, Bracciali con Zirconi, Bracciali con Pietre di Colore, Bracciali Uomo in Oro, Bracciali Uomo in Titanio, Bracciali Uomo Piastra, Bracciali Rosari, Bracciali per Bambini, Orecchini Punti Luce, Orecchini Pietre di Colore, Orecchini con Diamanti, Orecchini con Perle, Orecchini Oro, Orecchini Cerchi in Oro, Orecchini Oro Bambini, Anelli di fidanzamento, Fedine Eternity, Anelli Trilogy, Anelli con Diamanti, Anelli Pietre di Colore, Anelli Chevalier, Anelli Oro, Anelli Uomo, Medaglie Religiose, Ciondoli in oro, Croci Zodiaci, Iniziali e Numeri in Oro, Fedi Nuziali, Ciondolo Oro, Segni Zodiacali, Croci";

$data = fopen("data.csv", "r");
$newFile = fopen("strTOstr.csv", "w");

$header = fgetcsv($data); // saving a headaer
fputcsv($newFile, $header); // adding new column to first line

while (($row = fgetcsv($data)) !== false) {
    $rowAssoc = array_combine($header, $row);

    $tags = explode(",", $rowAssoc['Tags']); // csv tag in one array name with , coma
    foreach ($tags as $tag) {
        if (strpos($str, $tag) !== false) { // checking every word with that array
            $rowAssoc['Category'] .= '"' . $tag . '",'; // adding that data to category
        }
    }
    $rowAssoc['Category'];

    fputcsv($newFile, $rowAssoc); // adding to new file
}
echo "File Created...";
fclose($data);
fclose($newFile);
