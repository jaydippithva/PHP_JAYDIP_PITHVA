<?php

$data = fopen("data2.csv", "r");
$newFile = fopen("done2.csv", "w");

$header = fgetcsv($data); // saving a headaer

$newHeader = array_merge($header, [ // adding new column
    "Password",
    "include_tax_price",
    "Create_date"
]);

fputcsv($newFile, $newHeader); // adding new column to first line

while (($row = fgetcsv($data)) !== false) {
    $rowAssoc = array_combine($header, $row);
    if (!isset($rowAssoc['Number']) || !str_starts_with($rowAssoc['Number'], 'DR10')) { // Filter DR10 rows
        continue;
    }
    if (isset($rowAssoc['Date']) && is_numeric($rowAssoc['Date'])) { // Convert Date
        $rowAssoc['Date'] = date('d-m-Y', (int)$rowAssoc['Date']);
    }
    if (isset($rowAssoc['Number'])) { // Hash Number
        $rowAssoc['Password'] = md5($rowAssoc['Number']);
    }
    if (isset($rowAssoc['PurchasePrice']) && is_numeric($rowAssoc['PurchasePrice'])) { // Round PurchasePrice
        $rowAssoc['PurchasePrice'] = round((float)$rowAssoc['PurchasePrice']);
    }
    $taxPrice = '';
    if (isset($rowAssoc['price_with_taxes'])) { // Calculate Tax Price
        $value = str_replace(',', '', $rowAssoc['price_with_taxes']);
        if (is_numeric($value)) {
            $taxPrice = round((int)$value * 1.25);
            $rowAssoc['include_tax_price'] = $taxPrice;
        }
    }
    // Add new columns data
    $rowAssoc['Create_date'] = date('d-m-y');

    fputcsv($newFile, array_values($rowAssoc)); // adding to file
}

fclose($data);
fclose($newFile);

echo "One File Created...";
