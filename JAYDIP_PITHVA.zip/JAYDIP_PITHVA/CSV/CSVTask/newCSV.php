<?php
$data = fopen("data.csv", "r");
$newFile = fopen("DR10.csv", "w+");

$header = fgetcsv($data);
fputcsv($newFile, $header);

while (($row = fgetcsv($data)) !== FALSE) {
    $rowAssoc = array_combine($header, $row); // this combineing two array header and row in one array $rowAssoc
    if (isset($rowAssoc['Number']) && str_starts_with($rowAssoc['Number'], 'DR10')) {
        fputcsv($newFile, $row);
    }
}

// fclose($data);
// fclose($newFile);
echo "DR10 records written successfully!";

// 3) Convert date column[3] (1633427368) to Date format (dd-mm-yyyy) modify in data.csv file

// $input = fopen('data.csv', 'r');
$output = fopen('date_converted.csv', 'w');
$header = fgetcsv($input);
fputcsv($output, $header); // Write header to new file

while (($row = fgetcsv($input)) !== FALSE) {
    $rowAssoc = array_combine($header, $row);
    if (isset($rowAssoc['Date']) && is_numeric($rowAssoc['Date'])) {
        $rowAssoc['Date'] = date('d-m-Y', (int)$rowAssoc['Date']);
    }
    fputcsv($output, $rowAssoc);
}

fclose($input);
fclose($output);
echo "Date Conversion complete!";

// 4) Create new column in csv for "Password" and Encrypt Number column data to md5

$read = fopen('date_converted.csv', "r");
$write = fopen('pass_col_added.csv', "w");
$header = fgetcsv($read);
$header[] = "Password"; // Add new column name
fputcsv($write, $header); // Write updated header

while (($row = fgetcsv($read)) !== false) {
    $row[] = ''; // empty value for Password column
    fputcsv($write, $row);
}

fclose($read);
fclose($write);

echo "Password column added successfully!";

$read = fopen('pass_col_added.csv', "r");
$write = fopen('encrypted_number_col.csv', "w");
$header = fgetcsv($read);

fputcsv($write, $header);

while (($row = fgetcsv($read)) !== false) {
    $rowAssoc = array_combine($header, $row);
    if (isset($rowAssoc['Number'])) {
        $rowAssoc['Number'] = md5($rowAssoc['Number']);
    }

    fputcsv($write, $rowAssoc);
}

fclose($read);
fclose($write);
echo "Column encrypted successfully!";

// 5) Purchase Price column should be rounded value

$read = fopen('encrypted_number_col.csv', "r");
$write = fopen('rounded_price.csv', "w");
$header = fgetcsv($read);
fputcsv($write, $header); // $priceIndex = array_search('price', $header);

while (($row = fgetcsv($read)) !== false) {
    $rowAssoc = array_combine($header, $row);
    if (isset($rowAssoc['PurchasePrice']) && is_numeric($rowAssoc['PurchasePrice'])) {
        $rowAssoc['PurchasePrice'] = round((float)$rowAssoc['PurchasePrice']);
    }
    fputcsv($write, $rowAssoc);
}

fclose($read);
fclose($write);
echo "Column price rounded successfully!";

// 6) Create new column "indlude tax price" and set data from column price_with_taxes + 25%

$read = fopen('rounded_price.csv', "r");
$write = fopen('tax_price.csv', "w");
$header = fgetcsv($read);
$newHeader = $header;
$newHeader[] = "include_tax_price";
fputcsv($write, $newHeader);

while (($row = fgetcsv($read)) !== false) {
    $rowAssoc = array_combine($header, $row);
    $taxPrice = '';
    if (isset($rowAssoc['price_with_taxes'])) {
        $value = str_replace(',', '', $rowAssoc['price_with_taxes']);
        if (is_numeric($value)) {
            $taxPrice = round((int)$value * 1.25);
        }
    }
    $rowAssoc[] = $taxPrice;
    fputcsv($write, $rowAssoc);
}

fclose($read);
fclose($write);
echo "Tax Price column added successfully!";

// 7) Create new column "Create date"

$read = fopen('tax_price.csv', "r");
$write = fopen('create_date_col.csv', "w");
$header = fgetcsv($read);
$header[] = "Create_date";
fputcsv($write, $header);
// $currentDate = date('d-m-Y');

while (($row = fgetcsv($read)) !== false) {
    $row[] = '';
    fputcsv($write, $row);
}

fclose($read);
fclose($write);
echo "Create date column added successfully!";

// $lastCSV = fopen("create_date_col.csv", "r");
// while (! feof($lastCSV)) {
//     echo "<pre>";
//     print_r(fgetcsv($lastCSV));
//     echo "</pre>";
// }

// fclose($lastCSV);